// Integrates the variant sources into the deliverable folder.
const fs = require('fs'); const path = require('path');
const SP = '/tmp/claude-0/-home-user-radiara/431e9b97-f2c9-57aa-9d92-7907f96c1c0e/scratchpad';
const OUT = '/home/user/radiara/animaciones-originales-claude';
const V = (s) => SP + '/variants/' + s;
function build(dir, file) { const b = require(path.join(dir, file)); const c = require(path.join(dir, 'common.js')); return { b, svg: c.addFallbacks(c.sanitize(b.build())) + '\n' }; }
const ce = build(V('ce'), 'build-cash.js');
const tr = build(V('tr'), 'build-transfer.js');
const pos = build(V('pos'), 'build-pos.js');
fs.writeFileSync(OUT + '/contra-entrega.svg', ce.svg);
fs.writeFileSync(OUT + '/transferencia.svg', tr.svg);
fs.writeFileSync(OUT + '/tarjeta-pos.svg', pos.svg);
const read = (p) => fs.readFileSync(p, 'utf8');
const css = read(SP + '/css/base.css') + read(V('ce') + '/ce.css') + '\n' + read(V('tr') + '/tr.css') + '\n' + read(V('pos') + '/pos.css') + '\n' + read(SP + '/css/controls.css');
fs.writeFileSync(OUT + '/animations.css', css);
let html = read(OUT + '/preview.html');
const tpl = ['contra-entrega', 'transferencia', 'tarjeta-pos'].map(n => `<template data-hsa-template="${n}">${read(OUT + '/' + n + '.svg').trim()}</template>`).join('\n');
html = html.replace(/<!-- hsa-templates:start -->[\s\S]*<!-- hsa-templates:end -->/, () => `<!-- hsa-templates:start -->\n${tpl}\n<!-- hsa-templates:end -->`);
fs.writeFileSync(OUT + '/preview.html', html);
for (const f of fs.readdirSync(OUT)) console.log(f.padEnd(22), fs.statSync(OUT + '/' + f).size);
