// tarjeta-pos · generador del SVG (y, ejecutado directamente, de los keyframes de pos.css)
//   node build-pos.js        -> reescribe el bloque de keyframes generado dentro de pos.css e imprime la tabla de tiempos
const G = require('./geom'); G.setSimplify(0.03);
const { f1, fillv, strokev, stop, qGlyph } = require('./common');

// Terminal: cabeza de 64 u (x-2 .. x+62) con impresora, lector y pantalla; cintura suave bajo la pantalla
// hasta 58 u (x+1 .. x+59) donde va el teclado. Radio 10.5 arriba y abajo.
const POS = { x: 156, y: 54, w: 60, h: 108, r: 10.5 };
const HEAD = { l: -2, r: 62, y0: 60, y1: 72 }, WAIST = { l: 1, r: 59 };   // relativos a POS.x / POS.y
const RZ = { x: POS.x + 4, y: POS.y + 10.6, w: POS.w - 8, h: 15.6, r: 5 };    // zona del lector (bajo la tapa de impresora)
const SCR = { x: POS.x + 4.8, y: POS.y + 30, w: POS.w - 9.6, h: 28, r: 3.6 };   // pantalla
const CARD = { w: 60, h: 37.8, r: 3.3 };
const REST = { x: 90, y: 112, a: -12 }, READ = { x: 164, y: 61, a: -5 };
const MARK_C = [POS.x + 26.5, RZ.y + RZ.h / 2];           // marca del lector (queda bajo la tarjeta en lectura)
const WAVE_C = [MARK_C[0] + 1, MARK_C[1]];                // las ondas son frentes concéntricos a la marca
const SH = { c: [0.7, 1.2], a: [2.2, 3.8], b: [3.2, 5.5] }; // contacto / ambiental sobre el terminal; ambiental sobre la pared

// Marca sin contacto genérica: punto + 3 arcos de separación desigual (no es el símbolo de EMVCo).
function cmark(cx, cy, k, style, sw) {
  const R = [2.3, 4.6, 7.4], A = [0.86, 0.82, 0.78];
  let d = '';
  R.forEach((r0, i) => { const r = r0 * k, a = A[i]; d += `M${f1(cx + r * Math.cos(-a))} ${f1(cy + r * Math.sin(-a))}A${f1(r)} ${f1(r)} 0 0 1 ${f1(cx + r * Math.cos(a))} ${f1(cy + r * Math.sin(a))}`; });
  return `<path d="${d}" fill="none" ${style} stroke-width="${sw}" stroke-linecap="round"/><circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(0.95 * k)}" ${style.replace(/stroke:/g, 'fill:').replace(/stroke-opacity/g, 'fill-opacity')}/>`;
}
const rr = (x, y, w, h, r, extra) => `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" rx="${f1(r)}" ${extra}/>`;
// contorno superior + izquierdo de un rectángulo redondeado (bisel de luz)
function bevelPath(x, y, w, h, r, inset) {
  const i = inset, R = r - i;
  return `M${f1(x + i)} ${f1(y + h - r)}V${f1(y + r)}A${f1(R)} ${f1(R)} 0 0 1 ${f1(x + r)} ${f1(y + i)}H${f1(x + w - r)}`;
}
// silueta del datáfono, con margen interior i y desplazamiento horizontal dx
function bodyD(i = 0, dx = 0) {
  const { x, y, h, r } = POS, R = r - i, X = x + dx;
  const L0 = X + HEAD.l + i, R0 = X + HEAD.r - i, L1 = X + WAIST.l + i, R1 = X + WAIST.r - i;
  const T = y + i, B = y + h - i, yA = y + HEAD.y0, yB = y + HEAD.y1, yM = (yA + yB) / 2;
  return `M${f1(L0)} ${f1(T + R)}A${f1(R)} ${f1(R)} 0 0 1 ${f1(L0 + R)} ${f1(T)}H${f1(R0 - R)}A${f1(R)} ${f1(R)} 0 0 1 ${f1(R0)} ${f1(T + R)}` +
    `V${f1(yA)}C${f1(R0)} ${f1(yM)} ${f1(R1)} ${f1(yM)} ${f1(R1)} ${f1(yB)}V${f1(B - R)}A${f1(R)} ${f1(R)} 0 0 1 ${f1(R1 - R)} ${f1(B)}` +
    `H${f1(L1 + R)}A${f1(R)} ${f1(R)} 0 0 1 ${f1(L1)} ${f1(B - R)}V${f1(yB)}C${f1(L1)} ${f1(yM)} ${f1(L0)} ${f1(yM)} ${f1(L0)} ${f1(yA)}Z`;
}

// Parte 1: carcasa (recibe la sombra oscura de la tarjeta): suelo, cuerpo, franjas, contorno, bisel, tapa, lector, marco de pantalla, teclado
function terminalBody() {
  const { x, y, w, h, r } = POS; let s = '';
  const cxm = x + w / 2;
  // sombras en el suelo: ambiental suave + contacto ajustada, ambas hacia abajo-derecha; rebote cálido (solo noche)
  s += `<ellipse cx="${cxm + 7}" cy="${y + h + 1}" rx="${w * 0.72}" ry="5.4" fill="url(#pos-gamb)"/>`;
  s += `<ellipse cx="${cxm + 2}" cy="${y + h}" rx="${w * 0.56}" ry="2.2" fill="url(#pos-gcon)"/>`;
  s += `<ellipse cx="${cxm}" cy="${y + h + 1}" rx="${w * 0.9}" ry="6" fill="url(#pos-bounce)"/>`;
  // cuerpo: degradado de 3 paradas + franja lateral derecha interior que sigue la silueta (par/impar con la silueta desplazada)
  s += `<path d="${bodyD()}" fill="url(#pos-body)"/>`;
  s += `<g clip-path="url(#pos-bodyclip)">`;
  s += `<path d="${bodyD()}${bodyD(0, -3.6)}" fill-rule="evenodd" ${fillv('pos-side', '#2A2018', ';opacity:.5')}/>`;
  s += `<path d="${bodyD()}${bodyD(0, -1.7)}" fill-rule="evenodd" ${fillv('pos-side', '#2A2018', ';opacity:.6')}/>`;
  s += rr(x - 2, y + h - 2.2, w + 4, 4, 0, fillv('pos-body-lo', '#33281F', ';opacity:.7'));
  s += `</g>`;
  // contorno: degradado en espacio de usuario, claro arriba-izquierda y oscuro abajo-derecha (de día, uniforme)
  s += `<path d="${bodyD(0.45)}" fill="none" stroke="url(#pos-contourgrad)" style="stroke-opacity:var(--pos-contour-a,.9)" stroke-width=".9"/>`;
  // bisel de luz arriba-izquierda que se desvanece hacia los extremos (único rim de noche)
  const L = x + HEAD.l, Rr = r - 0.6;
  s += `<path d="M${f1(L + .6)} ${f1(y + HEAD.y0 - 2)}V${f1(y + r)}A${f1(Rr)} ${f1(Rr)} 0 0 1 ${f1(L + r)} ${f1(y + .6)}H${f1(x + HEAD.r - r)}" fill="none" stroke="url(#pos-bevelgrad)" style="stroke-opacity:var(--pos-bevel-a,.7)" stroke-width=".8" stroke-linecap="round"/>`;
  // tapa de impresora: junta a y+8.6 y ranura ancha
  s += `<path d="M${f1(L + .9)} ${f1(y + 8.6)}H${f1(x + HEAD.r - .9)}" ${strokev('pos-contour', '#1F1813', ';stroke-opacity:.5')} stroke-width=".6"/>`;
  s += `<path d="M${f1(L + 1.2)} ${f1(y + 9.3)}H${f1(x + HEAD.r - 1.2)}" ${strokev('pos-bevel', '#9A8268', ';stroke-opacity:.22')} stroke-width=".6"/>`;
  s += rr(x + 8, y + 3.3, w - 16, 2.1, 1.05, 'fill="url(#pos-slotgrad)"');
  // zona del lector + marca impresa (tono de tecla, no oro: el oro queda para las ondas)
  s += rr(RZ.x, RZ.y, RZ.w, RZ.h, RZ.r, 'fill="url(#pos-reader)"');
  s += `<path d="M${f1(RZ.x + RZ.r)} ${f1(RZ.y + RZ.h - .4)}H${f1(RZ.x + RZ.w - RZ.r)}" ${strokev('pos-bevel', '#9A8268', ';stroke-opacity:.3')} stroke-width=".6" stroke-linecap="round"/>`;
  s += cmark(MARK_C[0], MARK_C[1], 1.12, strokev('pos-key-ink', '#B4A28A', ';stroke-opacity:var(--pos-mark-a,.7)'), .75);
  // marco de pantalla (material de carcasa)
  const { x: sx, y: sy, w: sw, h: sh } = SCR;
  s += rr(sx - 1.6, sy - 1.6, sw + 3.2, sh + 3.2, 5, fillv('pos-bezel', '#2A2019'));
  // teclado sereno: 4 filas numéricas sin línea de luz ni relieve; fila de función tonal, 1 u más alta y más redonda
  const kx = x + 5.6, ky = y + 63.6, kw = 14.2, kh = 5.6, gx = (w - 11.2 - 3 * kw) / 2, gy = 3.0;
  for (let row = 0; row < 4; row++) for (let col = 0; col < 3; col++) {
    const X = kx + col * (kw + gx), Y = ky + row * (kh + gy);
    s += rr(X + .35, Y + .75, kw, kh, 2, fillv('pos-bezel', '#2A2019', ';opacity:.45'));
    s += rr(X, Y, kw, kh, 2, 'fill="url(#pos-key)"');
  }
  const fy = ky + 4 * (kh + gy) + .2, fh = kh + 1;
  const fk = [['pos-fk-1', '#7E6650'], ['pos-fk-2', '#8C7058'], ['pos-fk-3', '#7E6650']];
  fk.forEach(([tok, fb], col) => {
    const X = kx + col * (kw + gx);
    s += rr(X + .35, fy + .75, kw, fh, 3.1, fillv('pos-bezel', '#2A2019', ';opacity:.45'));
    s += rr(X, fy, kw, fh, 3.1, fillv(tok, fb));
    s += rr(X + 1.2, fy + .6, kw - 2.4, 2.2, 1.1, fillv('pos-key-gloss', '#FFFFFF', ';fill-opacity:var(--pos-key-gloss-a,.14)'));
  });
  return s;
}
// Parte 2: cara retroiluminada (recibe solo una sombra tenue y tostada): pantalla, brillo, Q, regla
function terminalFace() {
  const { x: sx, y: sy, w: sw, h: sh } = SCR; let s = '';
  s += rr(sx, sy, sw, sh, SCR.r, 'fill="url(#pos-screen)"');
  s += `<g class="pos-screen-glow" style="opacity:0">${rr(sx, sy, sw, sh, SCR.r, 'fill="url(#pos-screenglow)"')}</g>`;
  // Q centrada ópticamente (la cola desplaza la caja 0.5 u a la derecha) + una única regla fina
  s += qGlyph(sx + sw / 2 - 0.7, sy + 12.4, 0.8, fillv('pos-screen-ink', '#6B4E23'));
  s += `<path d="M${f1(sx + sw * 0.3)} ${f1(sy + 21.6)}H${f1(sx + sw * 0.7)}" ${strokev('pos-screen-ink', '#6B4E23', ';stroke-opacity:.14')} stroke-width=".6" stroke-linecap="round"/>`;
  s += `<path d="M${f1(sx + 2.4)} ${f1(sy + 1.3)}H${f1(sx + sw - 7)}" ${strokev('pos-screen-hl', '#FFFFFF', ';stroke-opacity:var(--pos-screen-hl-a,.6)')} stroke-width=".6" stroke-linecap="round"/>`;
  return s;
}

// Sombra de la tarjeta (forma local, sin filtros): 10 capas de alfa uniforme, ningún escalón > ~2 % de luminancia
function cardShadowShapes(tok, fb, k) {
  const { w, h, r } = CARD, x = -w / 2, y = -h / 2; let s = '';
  const a = f1(0.018 * k * 1000) / 1000;
  for (const g of [4.2, 3.6, 3.0, 2.5, 2.0, 1.6, 1.2, 0.8, 0.45, 0.15]) s += rr(x - g, y - g, w + 2 * g, h + 2 * g, r + g, fillv(tok, fb, `;opacity:${a}`));
  return s;
}
function cardContactShapes(tok, fb, k) {
  const { w, h, r } = CARD, x = -w / 2, y = -h / 2;
  return rr(x - .2, y - .2, w + .4, h + .4, r + .2, fillv(tok, fb, `;opacity:${k}`));
}
// Grupo animado con las mismas animaciones que la tarjeta; `off` es el desfase de la sombra en pantalla.
function follower(inner, off, cls) {
  return `<g class="pos-shoff ${cls}" transform="translate(${off[0]} ${off[1]})"><g class="pos-card-x" transform="translate(${READ.x} 0)"><g class="pos-card-y" transform="translate(0 ${READ.y}) rotate(${READ.a})">${inner}</g></g></g>`;
}

function card() {
  const { w, h, r } = CARD, x = -w / 2, y = -h / 2; let s = '';
  // canto (grosor) abajo-derecha
  s += rr(x + .45, y + .75, w, h, r, fillv('pos-card-edge', '#A9884F'));
  s += rr(x, y, w, h, r, 'fill="url(#pos-cardbody)"');
  s += `<g clip-path="url(#pos-cardclip)">`;
  // especular estático ancho (metal champán) + brillo de barrido solo durante la aproximación
  s += `<rect x="${x + 8}" y="${y - 8}" width="22" height="${h + 16}" transform="skewX(-22)" fill="url(#pos-spec)"/>`;
  s += `<g class="pos-card-sheen" style="opacity:0"><rect x="${x - 30}" y="${y - 8}" width="16" height="${h + 16}" transform="skewX(-22)" fill="url(#pos-sheen)"/></g>`;
  s += `</g>`;
  // chip
  const cx0 = x + 7.6, cy0 = y + 13.4, cw = 10.4, ch = 8.2;
  s += rr(cx0 + .3, cy0 + .5, cw, ch, 1.6, fillv('pos-card-detail', '#8E6B3A', ';opacity:.22'));
  s += rr(cx0, cy0, cw, ch, 1.6, 'fill="url(#pos-chip)"');
  s += `<path d="M${f1(cx0 + cw * .37)} ${cy0 + .4}V${f1(cy0 + ch - .4)}M${f1(cx0 + cw * .63)} ${cy0 + .4}V${f1(cy0 + ch - .4)}M${cx0 + .4} ${f1(cy0 + ch / 2)}H${f1(cx0 + cw * .37)}M${f1(cx0 + cw * .63)} ${f1(cy0 + ch / 2)}H${f1(cx0 + cw - .4)}" fill="none" ${strokev('pos-card-detail', '#8E6B3A', ';stroke-opacity:.5')} stroke-width=".6"/>`;
  s += rr(cx0, cy0, cw, ch, 1.6, `fill="none" ${strokev('pos-card-detail', '#8E6B3A', ';stroke-opacity:.8')} stroke-width=".6"`);
  s += `<path d="M${f1(cx0 + 1.6)} ${f1(cy0 + .75)}H${f1(cx0 + 1.6 + cw * .5)}" ${strokev('pos-card-rim', '#FFFFFF', ';stroke-opacity:.55')} stroke-width=".6" stroke-linecap="round"/>`;
  // marca sin contacto genérica junto al chip (punto + 3 arcos desiguales)
  s += cmark(cx0 + cw + 4.2, cy0 + ch / 2, 0.6, strokev('pos-card-detail', '#8E6B3A', ';stroke-opacity:.7'), .6);
  // emblema: dos rombos
  const ex = x + w - 10.5, ey = y + 8.4;
  s += `<path d="M${f1(ex - 3)} ${ey}l2.6-2.6 2.6 2.6-2.6 2.6z" fill="none" ${strokev('pos-card-detail', '#8E6B3A', ';stroke-opacity:.85')} stroke-width=".6" stroke-linejoin="round"/>`;
  s += `<path d="M${f1(ex + .5)} ${ey}l2.6-2.6 2.6 2.6-2.6 2.6z" ${fillv('pos-card-detail', '#8E6B3A', ';opacity:.8')}/>`;
  // bordes: luz arriba-izquierda (rim, dentro del contorno) + contorno de 0.9
  s += `<path d="${bevelPath(x, y, w, h, r, 1.25)}" fill="none" ${strokev('pos-card-rim', '#FFFFFF', ';stroke-opacity:var(--pos-card-rim-a,.7)')} stroke-width=".6" stroke-linecap="round"/>`;
  s += rr(x, y, w, h, r, `fill="none" ${strokev('pos-card-contour', '#7E5E31')} stroke-width=".9"`);
  return s;
}

const WAVE = { R: [15.5, 19.5, 23.5], HH: [5.4, 6.2, 6.8], O: [0.6, 0.4, 0.25], SW: [1.7, 1.6, 1.5] };
function waves() {
  // arcos fijos que se encienden en secuencia (interior -> exterior), abiertos hacia la derecha
  let s = '';
  WAVE.R.forEach((r, i) => {
    const a = Math.asin(WAVE.HH[i] / r), [cx, cy] = WAVE_C;
    const d = `M${f1(cx + r * Math.cos(-a))} ${f1(cy + r * Math.sin(-a))}A${r} ${r} 0 0 1 ${f1(cx + r * Math.cos(a))} ${f1(cy + r * Math.sin(a))}`;
    s += `<path class="pos-wave pos-wave--${i + 1}" d="${d}" fill="none" ${strokev('pos-wave', '#B8924A', `;opacity:${WAVE.O[i]}`)} stroke-width="${WAVE.SW[i]}" stroke-linecap="round"/>`;
  });
  return s;
}

function build() {
  const sa = (tok, fb, a) => `style="stop-color:var(--${tok},${fb});stop-opacity:var(--${tok}-a,${a})"`;
  const defs = `<defs>
<radialGradient id="pos-halo" cx=".5" cy=".5" r=".5"><stop offset="0" style="stop-color:var(--hsa-halo,#FFFFFF);stop-opacity:var(--hsa-halo-a,.85)"/><stop offset=".6" style="stop-color:var(--hsa-halo,#FFFFFF);stop-opacity:var(--hsa-halo-b,.35)"/><stop offset="1" style="stop-color:var(--hsa-halo,#FFFFFF);stop-opacity:0"/></radialGradient>
<linearGradient id="pos-ground" gradientUnits="userSpaceOnUse" x1="24" y1="0" x2="296" y2="0"><stop offset="0" style="stop-color:var(--pos-ground,#6B4E23);stop-opacity:0"/><stop offset=".5" ${sa('pos-ground', '#6B4E23', .18)}/><stop offset="1" style="stop-color:var(--pos-ground,#6B4E23);stop-opacity:0"/></linearGradient>
<radialGradient id="pos-gcon" cx=".5" cy=".5" r=".5"><stop offset="0" ${sa('pos-shadow-con', '#14100D', .38)}/><stop offset="1" style="stop-color:var(--pos-shadow-con,#14100D);stop-opacity:0"/></radialGradient>
<radialGradient id="pos-gamb" cx=".5" cy=".5" r=".5"><stop offset="0" ${sa('pos-shadow-amb', '#5A3A1E', .12)}/><stop offset="1" style="stop-color:var(--pos-shadow-amb,#5A3A1E);stop-opacity:0"/></radialGradient>
<radialGradient id="pos-bounce" cx=".5" cy=".5" r=".5"><stop offset="0" ${sa('pos-bounce', '#D9BC77', 0)}/><stop offset="1" style="stop-color:var(--pos-bounce,#D9BC77);stop-opacity:0"/></radialGradient>
<linearGradient id="pos-body" x1="0" y1="0" x2=".55" y2="1">${stop(0, 'pos-body-hi', '#6A5440')}${stop(0.45, 'pos-body', '#4C3B2C')}${stop(1, 'pos-body-lo', '#33281F')}</linearGradient>
<linearGradient id="pos-contourgrad" gradientUnits="userSpaceOnUse" x1="${POS.x}" y1="${POS.y}" x2="${POS.x + POS.w}" y2="${POS.y + POS.h}">${stop(0, 'pos-contour-hi', '#1F1813')}${stop(1, 'pos-contour-lo', '#1F1813')}</linearGradient>
<linearGradient id="pos-slotgrad" x1="0" y1="0" x2="0" y2="1">${stop(0, 'pos-slot-a', '#2E241C')}${stop(1, 'pos-slot-b', '#4A3B2E')}</linearGradient>
<linearGradient id="pos-reader" x1="0" y1="0" x2=".3" y2="1">${stop(0, 'pos-reader-hi', '#57463A')}${stop(1, 'pos-reader', '#3A2E23')}</linearGradient>
<linearGradient id="pos-screen" x1="0" y1="0" x2=".4" y2="1">${stop(0, 'pos-screen-hi', '#F6EFDF')}${stop(0.6, 'pos-screen', '#ECE2CB')}${stop(1, 'pos-screen-lo', '#DFD2B6')}</linearGradient>
<radialGradient id="pos-screenglow" cx=".5" cy=".55" r=".8"><stop offset="0" style="stop-color:var(--pos-glow,#FFFDF4);stop-opacity:var(--pos-glow-a,.75)"/><stop offset=".6" style="stop-color:var(--pos-glow,#FFFDF4);stop-opacity:var(--pos-glow-b,.3)"/>${stop(1, 'pos-glow', '#FFFDF4', 0)}</radialGradient>
<radialGradient id="pos-bevelgrad" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="1" gradientTransform="translate(${POS.x + 4} ${POS.y + 6}) scale(${POS.w - 9} ${POS.h - 52})">${stop(0, 'pos-bevel', '#9A8268', 1)}${stop(0.5, 'pos-bevel', '#9A8268', 1)}${stop(1, 'pos-bevel', '#9A8268', 0)}</radialGradient>
<linearGradient id="pos-key" x1="0" y1="0" x2=".3" y2="1">${stop(0, 'pos-key-hi', '#7A6550')}${stop(1, 'pos-key', '#5E4B3A')}</linearGradient>
<linearGradient id="pos-cardbody" x1="0" y1="0" x2="1" y2="1" gradientTransform="rotate(-6 .5 .5)">${stop(0, 'pos-card-hi', '#F0E2BE')}${stop(0.5, 'pos-card', '#E1C994')}${stop(1, 'pos-card-lo', '#C9A869')}</linearGradient>
<linearGradient id="pos-chip" x1="0" y1="0" x2="1" y2="1">${stop(0, 'pos-chip-hi', '#E9D3A0')}${stop(0.55, 'pos-chip', '#D1B275')}${stop(1, 'pos-chip-lo', '#B8924A')}</linearGradient>
<linearGradient id="pos-spec" x1="0" y1="0" x2="1" y2="0">${stop(0, 'pos-card-spec', '#FFFFFF', 0)}<stop offset=".5" style="stop-color:var(--pos-card-spec,#FFFFFF);stop-opacity:var(--pos-card-spec-a,.16)"/>${stop(1, 'pos-card-spec', '#FFFFFF', 0)}</linearGradient>
<linearGradient id="pos-sheen" x1="0" y1="0" x2="1" y2="0">${stop(0, 'pos-sheen', '#FFFFFF', 0)}${stop(0.5, 'pos-sheen', '#FFFFFF', 0.32)}${stop(1, 'pos-sheen', '#FFFFFF', 0)}</linearGradient>
<clipPath id="pos-cardclip"><rect x="${-CARD.w / 2}" y="${-CARD.h / 2}" width="${CARD.w}" height="${CARD.h}" rx="${CARD.r}"/></clipPath>
<clipPath id="pos-bodyclip"><path d="${bodyD()}"/></clipPath>
<clipPath id="pos-scrclip">${rr(SCR.x, SCR.y, SCR.w, SCR.h, SCR.r, '')}</clipPath>
<clipPath id="pos-waveclip"><rect x="${f1(MARK_C[0] + 13.5)}" y="${f1(RZ.y + .4)}" width="${f1(RZ.x + RZ.w - MARK_C[0] - 13.9)}" height="${f1(RZ.h - .8)}" rx="${RZ.r - .4}"/></clipPath>
</defs>`;
  // sombra sobre el fondo (debajo del terminal: el terminal la tapa), copia oscura recortada a la carcasa y copia tenue y tostada recortada a la pantalla
  const shBg = follower(cardShadowShapes('pos-shadow', '#5A3A1E', 0.55), SH.b, 'pos-shoff--b') + follower(cardContactShapes('pos-shadow', '#5A3A1E', .05), SH.c, 'pos-shoff--c');
  const shOn = follower(cardShadowShapes('pos-shadow-on', '#2A1B0E', 2.1), SH.a, 'pos-shoff--a') + follower(cardContactShapes('pos-shadow-on', '#2A1B0E', .11), SH.c, 'pos-shoff--c');
  const shScr = follower(cardShadowShapes('pos-shadow-scr', '#6B4E23', 1.1), SH.a, 'pos-shoff--a') + follower(cardContactShapes('pos-shadow-scr', '#6B4E23', .05), SH.c, 'pos-shoff--c');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180" class="hsa-scene hsa-pos" aria-hidden="true" focusable="false">
${defs}
<g class="pos-backdrop">
<ellipse cx="160" cy="92" rx="150" ry="80" fill="url(#pos-halo)"/>
<path d="M24 161.8H296" stroke="url(#pos-ground)" stroke-width=".6"/>
</g>
<g class="pos-card-shadow">${shBg}</g>
<g class="pos-terminal">${terminalBody()}</g>
<g class="pos-card-shadow-on" clip-path="url(#pos-bodyclip)">${shOn}</g>
<g class="pos-terminal-face">${terminalFace()}</g>
<g class="pos-card-shadow-scr" clip-path="url(#pos-scrclip)">${shScr}</g>
<g class="pos-waves" clip-path="url(#pos-waveclip)">${waves()}</g>
<g class="pos-card-x" transform="translate(${READ.x} 0)"><g class="pos-card-y" transform="translate(0 ${READ.y}) rotate(${READ.a})">${card()}</g></g>
</svg>`;
}

/* ---------- Movimiento (segundos -> %), escrito en pos.css por `node build-pos.js` ---------- */
const DUR = 5.6;
const E = {
  hold: 'cubic-bezier(.4, 0, .6, 1)',
  windup: 'cubic-bezier(.4, 0, .6, 1)',
  glideX: 'cubic-bezier(.38, .04, .3, 1)',     // x: arranca tarde y aterriza largo -> y lidera, arco claro
  leadY: 'cubic-bezier(.3, 0, .2, 1)',        // y: sube primero y pasa 1.8 u por encima (único sobrepaso)
  settle: 'cubic-bezier(.3, 0, .3, 1)',
  tapIn: 'cubic-bezier(.3, 0, .6, 1)',        // toque en profundidad: 120 ms hacia la cara del lector
  tapOut: 'cubic-bezier(.2, 0, .2, 1)',
  liftY: 'cubic-bezier(.4, 0, .45, 1)',
  backX: 'cubic-bezier(.45, 0, .25, 1)',      // retirada: x sale primero ...
  lagY: 'cubic-bezier(.6, 0, .4, 1)',         // ... y se queda arriba y cae después: el arco se curva hacia el mismo lado que la ida
  rise: 'cubic-bezier(.2, 0, .4, 1)',
  fall: 'cubic-bezier(.45, 0, .6, 1)',
};
const pc = (t) => `${+(t / DUR * 100).toFixed(2)}%`;
function kf(name, rows) {
  return `@keyframes ${name} {\n` + rows.map(([t, d, e]) => `  ${Array.isArray(t) ? t.map(pc).join(', ') : pc(t)} { ${d}${e ? `; animation-timing-function: ${e}` : ''}; }`).join('\n') + `\n}`;
}
const tx = (v) => `transform: translateX(${+v.toFixed(2)}px)`;
const ty = (v, a, k = 1) => `transform: translateY(${+v.toFixed(2)}px) rotate(${+a.toFixed(2)}deg) scale(${k})`;
const T = {
  windup: 0.40, go: 0.66, over: 1.20, arrive: 1.52, settled: 1.70, tapIn: 2.02, tapPeak: 2.14, tapBack: 2.40,
  readEnd: 3.10, depart: 3.22, lift: 3.30, homeX: 4.02, homeY: 4.08,
};
const WT = { start: T.tapPeak + 0.14, step: 0.12, up: 0.12, down: 0.38, peak: 0.9 };   // ondas
const GT = { up: 0.25, hold: 0.15, down: 0.38, peak: 0.6 };                          // brillo de pantalla
function motionCSS() {
  const { x: X0, y: Y0, a: A0 } = REST, { x: XR, y: YR, a: AR } = READ;
  const x = kf('pos-card-x', [
    [[0, T.windup], tx(X0), E.windup],
    [T.go, tx(X0 - 3.6), E.glideX],
    [[T.arrive, T.tapIn], tx(XR), E.tapIn],
    [T.tapPeak, tx(XR + 0.3), E.tapOut],
    [[T.tapBack, T.depart], tx(XR), E.backX],
    [[T.homeX, DUR], tx(X0)],
  ]);
  const y = kf('pos-card-y', [
    [[0, T.windup], ty(Y0, A0), E.windup],
    [T.go, ty(Y0 + 2.6, A0 - 2.2), E.leadY],
    [T.over, ty(YR - 1.8, AR + 1.2), E.settle],
    [[T.settled, T.tapIn], ty(YR, AR), E.tapIn],
    [T.tapPeak, ty(YR + 0.8, AR + 0.6, 0.955), E.tapOut],
    [[T.tapBack, T.readEnd], ty(YR, AR), E.liftY],
    [T.lift, ty(YR - 1.5, AR + 1.4), E.lagY],
    [[T.homeY, DUR], ty(Y0, A0)],
  ]);
  // la sombra casi se cierra bajo la tarjeta en el toque (la tarjeta baja hacia el lector)
  const sh = (o, k) => `transform: translate(${+(o[0] * k).toFixed(2)}px, ${+(o[1] * k).toFixed(2)}px)`;
  const shoff = (n, o) => kf(n, [
    [[0, T.tapIn], sh(o, 1), E.tapIn],
    [T.tapPeak, sh(o, 0.15), E.tapOut],
    [[T.tapBack, DUR], sh(o, 1)],
  ]);
  const sheen = kf('pos-sheen', [
    [[0, 0.90], 'transform: translateX(0); opacity: 0', E.hold],
    [1.06, 'opacity: 1', E.hold],
    [[1.60, DUR], 'transform: translateX(104px); opacity: 0'],
  ]);
  // ondas: arcos fijos concéntricos al lector, solo opacidad; una pasada interior -> exterior causada por el toque
  const waves = [0, 1, 2].map((i) => {
    const c1 = WT.start + i * WT.step;
    return kf(`pos-wave-${i + 1}`, [
      [[0, c1 - WT.up], 'opacity: 0', E.rise],
      [c1, `opacity: ${WT.peak}`, E.fall],
      [[c1 + WT.down, DUR], 'opacity: 0'],
    ]);
  }).join('\n');
  // pantalla: un único respiro de retroiluminación tras el toque, sin segundo pulso ni estado final
  const glow = kf('pos-glow', [
    [[0, T.tapPeak], 'opacity: 0', E.rise],
    [T.tapPeak + GT.up, `opacity: ${GT.peak}`, E.hold],
    [T.tapPeak + GT.up + GT.hold, `opacity: ${GT.peak}`, E.fall],
    [[T.tapPeak + GT.up + GT.hold + GT.down, DUR], 'opacity: 0'],
  ]);
  return [x, y, shoff('pos-shoff-a', SH.a), shoff('pos-shoff-b', SH.b), shoff('pos-shoff-c', SH.c), sheen, waves, glow].join('\n');
}
// Tabla de tiempos derivada del código (para el informe y el comentario de pos.css)
function timing() {
  const wavesEnd = WT.start + 2 * WT.step + WT.down, glowEnd = T.tapPeak + GT.up + GT.hold + GT.down, sheenEnd = 1.60;
  const still = [[0, T.windup], [Math.max(T.settled, sheenEnd), T.tapIn], [Math.max(wavesEnd, glowEnd), T.readEnd], [T.homeY, DUR]];
  const stillS = still.reduce((a, [p, q]) => a + Math.max(0, q - p), 0);
  const approach = T.settled - T.go, retreat = T.homeY - T.readEnd;
  return {
    DUR, READ, REST, T, wavesEnd: +wavesEnd.toFixed(2), glowEnd: +glowEnd.toFixed(2),
    approach_s: +approach.toFixed(2), travelIn_s: +(T.arrive - T.go).toFixed(2), retreat_s: +retreat.toFixed(2), travelOut_s: +(T.homeX - T.depart).toFixed(2),
    restStill_s: +(DUR - T.homeY + T.windup).toFixed(2), sceneStill_s: +stillS.toFixed(2), sceneStill_pct: +(stillS / DUR * 100).toFixed(1),
    signalsEndBeforeLeave: Math.max(wavesEnd, glowEnd) < T.readEnd,
  };
}

function css() { return { REST, READ }; }
module.exports = { build, css, motionCSS, timing, REST, READ, DUR, T };

if (require.main === module) {
  const fs = require('fs'), p = __dirname + '/pos.css';
  let s = fs.readFileSync(p, 'utf8');
  const A = '/* @generated:keyframes:start */', Z = '/* @generated:keyframes:end */';
  const a = s.indexOf(A), z = s.indexOf(Z);
  if (a < 0 || z < a) throw new Error('marcadores no encontrados en pos.css');
  const t = timing();
  const table = `/* tiempos (s, bucle ${DUR}): ` + Object.entries(T).map(([k, v]) => `${k} ${v}`).join(' · ') +
    `\n   READ ${JSON.stringify(READ)} · REST ${JSON.stringify(REST)} · ondas hasta ${t.wavesEnd} · brillo hasta ${t.glowEnd}` +
    `\n   aproximación ${t.approach_s} s (recorrido ${t.travelIn_s}) · retirada ${t.retreat_s} s (recorrido ${t.travelOut_s}) · reposo quieto ${t.restStill_s} s · escena quieta ${t.sceneStill_s} s = ${t.sceneStill_pct} % */`;
  s = s.slice(0, a + A.length) + '\n' + table + '\n' + motionCSS() + '\n' + s.slice(z);
  s = s.replace(/--hsa-pos-dur: [\d.]+s/, `--hsa-pos-dur: ${DUR}s`);
  fs.writeFileSync(p, s); console.log('pos.css keyframes actualizados'); console.log(JSON.stringify(t, null, 1));
}
