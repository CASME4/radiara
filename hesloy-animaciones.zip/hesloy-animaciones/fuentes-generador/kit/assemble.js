// node assemble.js [overrideDir] > animations.css  — base + modules (override dir wins per module) + controls
const fs = require('fs'); const SP = '/tmp/claude-0/-home-user-radiara/431e9b97-f2c9-57aa-9d92-7907f96c1c0e/scratchpad';
const o = process.argv[2]; const pick = (f) => (o && fs.existsSync(o + '/' + f)) ? fs.readFileSync(o + '/' + f, 'utf8') : fs.readFileSync(SP + '/css/' + f, 'utf8');
process.stdout.write(pick('base.css') + pick('ce.css') + '\n' + pick('tr.css') + '\n' + pick('pos.css') + '\n' + pick('controls.css'));
