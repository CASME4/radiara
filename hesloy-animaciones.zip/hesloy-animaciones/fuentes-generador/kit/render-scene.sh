#!/usr/bin/env bash
# usage: render-scene.sh <dir> <transferencia|tarjeta-pos>
# Builds <dir>/build-transfer.js or <dir>/build-pos.js into <dir>/out/<scene>.svg. For transferencia, re-injects the
# path-sampled tr-coin / tr-lit keyframes from build-transfer.js css() into <dir>/tr.css (between '@keyframes tr-coin {' and
# '@keyframes tr-pulse-origen' if those markers exist). Assembles CSS = base + <dir> modules, renders PNGs into <dir>/renders.
set -e
D="$(cd "$1" && pwd)"; S="$2"; SP=/tmp/claude-0/-home-user-radiara/431e9b97-f2c9-57aa-9d92-7907f96c1c0e/scratchpad
mkdir -p "$D/out" "$D/renders"
B=build-pos.js; M=pos.css; [ "$S" = transferencia ] && B=build-transfer.js && M=tr.css
[ -f "$D/$M" ] || cp "$SP/css/$M" "$D/$M"
node -e "
const fs=require('fs'); const b=require('$D/$B'); const c=require('$D/common.js');
fs.writeFileSync('$D/out/$S.svg', c.addFallbacks(c.sanitize(b.build()))+'\n');
if ('$S'==='transferencia' && b.css) { const k=b.css(); let css=fs.readFileSync('$D/$M','utf8');
  const a=css.indexOf('@keyframes tr-coin {'), z=css.indexOf('@keyframes tr-pulse-origen');
  if (a>=0 && z>a && k.coin && k.lit) { css=css.slice(0,a)+'@keyframes tr-coin {\n'+k.coin+'\n}\n@keyframes tr-lit {\n'+k.lit+'\n}\n'+css.slice(z); fs.writeFileSync('$D/$M',css); } }
"
python3 -c "import xml.etree.ElementTree as ET; ET.parse('$D/out/$S.svg'); print('XML OK')"
node $SP/kit/assemble.js "$D" > "$D/out/assembled.css"; CSS="$D/out/assembled.css"; echo "" > "$D/out/empty.css"
cd $SP
if [ "$S" = transferencia ]; then T1=${T1:-2000}; TS=${TS:-0,500,800,1100,1400,1700,2000,2400,2900,3500,4200,5000}; else T1=${T1:-2600}; TS=${TS:-0,500,800,1100,1400,1800,2200,2600,3000,3400,3900,4600}; fi
node bigframe.js "$D/out/$S.svg" "$CSS" "$D/renders/$S-dia.png" $T1 dia
node bigframe.js "$D/out/$S.svg" "$CSS" "$D/renders/$S-noche.png" $T1 noche
node bigframe.js "$D/out/$S.svg" "$D/out/empty.css" "$D/renders/$S-estatico-sin-css.png" 0 dia
node frames.js "$D/out/$S.svg" "$CSS" "$D/renders/$S-tira.png" $TS dia 300
node frames.js "$D/out/$S.svg" "$CSS" "$D/renders/$S-tira-noche.png" $TS noche 280
rm -f "$D"/renders/*.html; ls "$D/renders"
