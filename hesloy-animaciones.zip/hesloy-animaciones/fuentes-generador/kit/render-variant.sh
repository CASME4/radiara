#!/usr/bin/env bash
# usage: render-variant.sh <dir>   (contra-entrega)
# Builds <dir>/build-cash.js (with the dir's own geom/handgeo/common) and assembles CSS from base + <dir>/ce.css (if present).
# Writes <dir>/out/{contra-entrega.svg,contra-entrega-sin-billete.svg,assembled.css} and PNGs in <dir>/renders.
set -e
V="$(cd "$1" && pwd)"; SP=/tmp/claude-0/-home-user-radiara/431e9b97-f2c9-57aa-9d92-7907f96c1c0e/scratchpad
mkdir -p "$V/out" "$V/renders"
node -e "
const fs=require('fs'); const b=require('$V/build-cash.js'); const c=require('$V/common.js');
const fix=(x)=>c.addFallbacks(c.sanitize(x));
fs.writeFileSync('$V/out/contra-entrega.svg', fix(b.build())+'\n');
fs.writeFileSync('$V/out/contra-entrega-sin-billete.svg', fix(b.build({showBill:false}))+'\n');
"
python3 -c "import xml.etree.ElementTree as ET; ET.parse('$V/out/contra-entrega.svg'); print('XML OK')"
node $SP/kit/assemble.js "$V" > "$V/out/assembled.css"; CSS="$V/out/assembled.css"
echo "" > "$V/out/empty.css"
cd $SP
T_CONTACT=${T_CONTACT:-2300}; T_START=${T_START:-0}; T_RECEP=${T_RECEP:-3900}; T_RESET=${T_RESET:-6000}
node bigframe.js "$V/out/contra-entrega.svg" "$CSS" "$V/renders/contacto-dia.png" $T_CONTACT dia
node bigframe.js "$V/out/contra-entrega.svg" "$CSS" "$V/renders/inicio-dia.png" $T_START dia
node bigframe.js "$V/out/contra-entrega.svg" "$CSS" "$V/renders/recepcion-dia.png" $T_RECEP dia
node bigframe.js "$V/out/contra-entrega.svg" "$CSS" "$V/renders/reinicio-dia.png" $T_RESET dia
node bigframe.js "$V/out/contra-entrega.svg" "$CSS" "$V/renders/contacto-noche.png" $T_CONTACT noche
node bigframe.js "$V/out/contra-entrega.svg" "$V/out/empty.css" "$V/renders/estatico-sin-css.png" 0 dia
node bigframe.js "$V/out/contra-entrega-sin-billete.svg" "$V/out/empty.css" "$V/renders/sin-billete-dia.png" 0 dia
node bigframe.js "$V/out/contra-entrega-sin-billete.svg" "$V/out/empty.css" "$V/renders/sin-billete-izq-x4.png" 0 dia 20 140 440 300
node bigframe.js "$V/out/contra-entrega-sin-billete.svg" "$V/out/empty.css" "$V/renders/sin-billete-der-x4.png" 0 dia 500 140 440 300
node bigframe.js "$V/out/contra-entrega.svg" "$V/out/empty.css" "$V/renders/contacto-izq-x4.png" 0 dia 20 140 440 300
node bigframe.js "$V/out/contra-entrega.svg" "$V/out/empty.css" "$V/renders/contacto-der-x4.png" 0 dia 500 140 440 300
node frames.js "$V/out/contra-entrega.svg" "$CSS" "$V/renders/tira.png" ${STRIP:-0,500,1000,1500,2000,2500,3000,3500,4000,4500,5300,6100} dia 300
node frames.js "$V/out/contra-entrega.svg" "$CSS" "$V/renders/tira-noche-280.png" ${STRIP3:-0,2300,3900} noche 280
rm -f "$V"/renders/*.html; ls "$V/renders"
