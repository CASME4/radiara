// node frames.js svgfile cssfile out.png times(ms,comma) [theme] [width]
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
(async () => {
  const [,, svgf, cssf, out, times, theme = 'dia', W = '300'] = process.argv;
  const svg = fs.readFileSync(svgf, 'utf8'), css = fs.readFileSync(cssf, 'utf8');
  const T = times.split(',').map(Number);
  const bg = theme === 'noche' ? '#0C0A09' : '#F4F1EA';
  const html = `<!doctype html><style>${css} body{margin:0;background:${bg};font:11px system-ui;color:#888} .g{display:grid;grid-template-columns:repeat(3,${W}px);gap:8px;padding:8px}</style>
<body data-hsa-theme="${theme}"><div class="g">${T.map(t => `<div><div>${t} ms</div>${svg}</div>`).join('')}</div></body>`;
  fs.writeFileSync(out + '.html', html);
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 3 * (+W + 8) + 8, height: 400 }, deviceScaleFactor: 2 });
  await p.goto('file://' + out + '.html'); await p.waitForTimeout(200);
  await p.evaluate((T) => {
    const scenes = [...document.querySelectorAll('svg')];
    scenes.forEach((s, i) => s.getAnimations({ subtree: true }).forEach(a => { a.pause(); a.currentTime = T[i]; }));
  }, T);
  await p.waitForTimeout(100);
  await p.screenshot({ path: out, fullPage: true }); await b.close();
})();
