// node bigframe.js svg css out.png timeMs theme [clipX clipY clipW clipH]
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
(async () => {
  const [,, svgf, cssf, out, t, theme = 'dia', cx, cy, cw, ch] = process.argv;
  const svg = fs.readFileSync(svgf, 'utf8'), css = fs.readFileSync(cssf, 'utf8');
  const bg = theme === 'noche' ? '#0C0A09' : '#F4F1EA';
  fs.writeFileSync(out + '.html', `<!doctype html><style>${css} body{margin:0;background:${bg}}</style><body data-hsa-theme="${theme}"><div style="width:960px">${svg}</div></body>`);
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 960, height: 540 }, deviceScaleFactor: 2 });
  await p.goto('file://' + out + '.html'); await p.waitForTimeout(200);
  await p.evaluate((t) => document.getAnimations().forEach(a => { a.pause(); a.currentTime = +t; }), t);
  await p.waitForTimeout(80);
  const opt = { path: out }; if (cx) opt.clip = { x: +cx, y: +cy, width: +cw, height: +ch };
  await p.screenshot(opt); await b.close();
})();
