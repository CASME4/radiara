'use strict';
/* node check-lock.js [svg] [css]
 * Proves numerically, in a real browser (Playwright/Chromium), that the contra-entrega motion is rigid and locked:
 *  - samples every 0.5 % of the loop with all animations paused at that time;
 *  - reads each group's CTM in SVG user units (root.getScreenCTM()^-1 * el.getScreenCTM()) and its opacity;
 *  - bill A must have exactly the transform of the hand that holds it: giver until the tug, receiver from the tug
 *    until it has dissolved, giver again after its (invisible) jump; bill B (the <use> copy) always the giver;
 *    --back/--front layers of a hand must be identical; each rigid thumb layer must rotate about its declared
 *    pivot (the pivot point never moves relative to the hand);
 *  - the A/B relay is invisible: same CTM at the relay and pixel-identical screenshots just before / after it;
 *  - compares 0 % and 100 % (declared keyframes, computed matrices/opacities, screenshots) of every group;
 *  - every discontinuity (frame-to-frame jump) of a group must happen while that group is invisible; the hands,
 *    the stage and the halo never change opacity; there is always a bill on screen (opacity sum A + B);
 *  - extra QA: peak speed (px/frame @300 px, 60 Hz), stillness share, finger "peek" above the visible bill's top
 *    edge, gaps between the free hand and the bill at rest, thumb clearance after release, cuffs vs the edge fade,
 *    prefers-reduced-motion = markup contact pose (bill A visible, bill B hidden).
 */
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'), path = require('path');
const DIR = __dirname;
const svgF = process.argv[2] || DIR + '/out/contra-entrega.svg';
const cssF = process.argv[3] || DIR + '/out/assembled.css';
const PIV = require(DIR + '/build-cash.js').PIVOTS;
const CONT = JSON.parse(fs.readFileSync(DIR + '/tools/contours.json', 'utf8'));   // layer outlines at contact (tools/contours.js)
const CUFF = JSON.parse(fs.readFileSync(DIR + '/tools/cuffs.json', 'utf8'));      // exact cuff polygons (tools/cuffpts.js)
const MOT = JSON.parse(fs.readFileSync(DIR + '/tools/motion.json', 'utf8'));
const DUR = MOT.dur, P = MOT.P, JB = P.jump + 0.01, SWB = P.swap + 0.01;
const B = PIV.bill;                                   // bill rect at contact (bill-local coords)
const BILLPTS = [[B.x, B.y], [B.x + B.w, B.y], [B.x, B.y + B.h], [B.x + B.w, B.y + B.h], [B.cx, B.cy]];
const SEL = {
  st: '.ce-stage', bd: '.ce-backdrop', gb: '.ce-giver--back', gf: '.ce-giver--front', rb: '.ce-receiver--back', rf: '.ce-receiver--front',
  a: '.ce-bill', bb: '.ce-bill-b', gt: '.ce-giver--front .ce-thumb', rt: '.ce-receiver--front .ce-thumb',
  gp: '.ce-giver--front .ce-press', rp: '.ce-receiver--front .ce-press',
};
const RIGID = ['gb', 'gf', 'rb', 'rf', 'a', 'bb', 'gt', 'rt'];
const ap = (m, p) => [m.a * p[0] + m.c * p[1] + m.e, m.b * p[0] + m.d * p[1] + m.f];
const inv = (m) => { const det = m.a * m.d - m.b * m.c; return { a: m.d / det, b: -m.b / det, c: -m.c / det, d: m.a / det, e: (m.c * m.f - m.d * m.e) / det, f: (m.b * m.e - m.a * m.f) / det }; };
const dev = (m1, m2, pts) => Math.max(...pts.map((p) => { const q1 = ap(m1, p), q2 = ap(m2, p); return Math.hypot(q1[0] - q2[0], q1[1] - q2[1]); }));
const rectDist = (p) => { const dx = Math.max(B.x - p[0], 0, p[0] - (B.x + B.w)), dy = Math.max(B.y - p[1], 0, p[1] - (B.y + B.h)); return Math.hypot(dx, dy); };
const inRect = (p) => p[0] > B.x && p[0] < B.x + B.w && p[1] > B.y && p[1] < B.y + B.h;
// canonical -> final placement matrices (the hands' inner <g transform>), to map the thumb pivots
const plM = (pl) => { const a = pl.rot * Math.PI / 180, c = Math.cos(a) * pl.s, s = Math.sin(a) * pl.s, mx = pl.mirror ? -1 : 1; return { a: c * mx, b: s * mx, c: -s, d: c, e: pl.tx, f: pl.ty }; };
const PIVG = ap(plM(PIV.giver.place), PIV.giver.thumbPivotLocal), PIVR = ap(plM(PIV.receiver.place), PIV.receiver.thumbPivotLocal);
// thumb-layer CTMs map CANONICAL hand coords: their traced outlines (stage coords) are brought back into that space
const toLocal = (pl, pts) => pts.map((p) => ap(inv(plM(pl)), p));
const ptsOf = { gb: CONT['ce-giver--back'], gf: CONT['ce-giver--front'], rb: CONT['ce-receiver--back'], rf: CONT['ce-receiver--front'], a: BILLPTS, bb: BILLPTS,
  gt: toLocal(PIV.giver.place, CONT['ce-giver-thumb']), rt: toLocal(PIV.receiver.place, CONT['ce-receiver-thumb']) };
// the opacity that hides a group's discontinuities (hands: none -> any jump fails)
const hideOp = (s, k) => (k === 'a' ? s.a.op : k === 'bb' ? s.bb.op : 1);

(async () => {
  const svg = fs.readFileSync(svgF, 'utf8'), css = fs.readFileSync(cssF, 'utf8');
  const html = DIR + '/tools/check-lock.html';
  fs.writeFileSync(html, `<!doctype html><style>${css} body{margin:0;background:#F4F1EA}</style><body data-hsa-theme="dia"><div style="width:960px">${svg}</div></body>`);
  const br = await chromium.launch(); const pg = await br.newPage({ viewport: { width: 960, height: 540 } });
  await pg.goto('file://' + html); await pg.waitForTimeout(150);
  await pg.evaluate(() => document.getAnimations().forEach((a) => a.pause()));
  const sample = (tms) => pg.evaluate(([t, SEL]) => {
    document.getAnimations().forEach((a) => { a.currentTime = t; });
    const root = document.querySelector('svg.hsa-ce'); const R = root.getScreenCTM().inverse();
    const out = {};
    for (const [k, s] of Object.entries(SEL)) {
      const el = document.querySelector(s); const m = R.multiply(el.getScreenCTM());
      out[k] = { m: { a: m.a, b: m.b, c: m.c, d: m.d, e: m.e, f: m.f }, op: +getComputedStyle(el).opacity };
    }
    return out;
  }, [tms, SEL]);
  const nAnim = await pg.evaluate(() => document.getAnimations().length);
  const T = (pc) => Math.min(pc / 100 * DUR, DUR - 1e-4);

  // ---------------------------------------------------------------- lock, every 0.5 % (+ the phase boundaries)
  const lock = { giverHeld: 0, receiverHeld: 0, contactBoth: 0, billB: 0, relay: 0, layersG: 0, layersR: 0, thumbPivotG: 0, thumbPivotR: 0 };
  const lockAt = {};
  const pcs = [...Array(201).keys()].map((i) => i / 2).concat([P.swap, SWB, P.t0, P.jump, JB, P.pivot]).sort((x, y) => x - y);
  for (const pc of pcs) {
    const s = await sample(T(pc));
    const upd = (k, v) => { if (v > lock[k]) { lock[k] = v; lockAt[k] = pc; } };
    const recv = pc >= P.t0 && pc < JB;
    if (!recv) upd('giverHeld', dev(s.a.m, s.gb.m, BILLPTS)); else upd('receiverHeld', dev(s.a.m, s.rb.m, BILLPTS));
    if (pc >= P.rp1 && pc <= P.t0) upd('contactBoth', Math.max(dev(s.a.m, s.gb.m, BILLPTS), dev(s.a.m, s.rb.m, BILLPTS)));
    upd('billB', dev(s.bb.m, s.gb.m, BILLPTS));
    if (pc < P.t0) upd('relay', dev(s.a.m, s.bb.m, BILLPTS));
    upd('layersG', dev(s.gb.m, s.gf.m, BILLPTS)); upd('layersR', dev(s.rb.m, s.rf.m, BILLPTS));
    const pv = (hand, thumb, fin, loc) => { const q1 = ap(hand.m, fin), q2 = ap(thumb.m, loc); return Math.hypot(q1[0] - q2[0], q1[1] - q2[1]); };
    upd('thumbPivotG', pv(s.gf, s.gt, PIVG, PIV.giver.thumbPivotLocal)); upd('thumbPivotR', pv(s.rf, s.rt, PIVR, PIV.receiver.thumbPivotLocal));
  }
  // ---------------------------------------------------------------- 0 % vs 100 %
  const s0 = await sample(0), s1 = await sample(DUR - 1e-4);
  const seam = {};
  for (const k of Object.keys(SEL)) {
    const d = dev(s0[k].m, s1[k].m, BILLPTS), dop = Math.abs(s0[k].op - s1[k].op);
    seam[k] = { matrixDiff: +d.toFixed(5), opacity0: s0[k].op, opacity100: +s1[k].op.toFixed(4), ok: dop < 1e-3 && (d < 1e-3 || (s0[k].op === 0 && s1[k].op < 1e-3)) };
  }
  const declared = await pg.evaluate(() => {
    const res = {};
    for (const sh of document.styleSheets) for (const r of sh.cssRules) {
      if (r.type !== CSSRule.KEYFRAMES_RULE || !r.name.startsWith('ce-')) continue;
      const at = (p) => { let v = null; for (const k of r.cssRules) if (k.keyText.split(',').map((x) => x.trim()).includes(p)) v = k.style; return v; };
      const a = at('0%'), b = at('100%'); const props = new Set();
      for (const k of r.cssRules) for (let i = 0; i < k.style.length; i++) if (k.style[i] !== 'animation-timing-function') props.add(k.style[i]);
      res[r.name] = [...props].map((p) => ({ p, v0: a && a.getPropertyValue(p), v100: b && b.getPropertyValue(p) }));
    }
    return res;
  });
  const declDiff = [];
  for (const [n, list] of Object.entries(declared)) for (const { p, v0, v100 } of list) if (v0 !== v100) declDiff.push(`${n}.${p}: 0%=${v0} 100%=${v100}`);

  // ---------------------------------------------------------------- jumps: every 0.05 % (2.8 ms) over the loop
  const jumps = []; let prevF = null; let minBill = { v: Infinity }, maxBill = { v: 0 }, billLow = 0, billDouble = 0; const opChange = new Set();
  for (let i = 0; i <= 2000; i++) {
    const pc = i / 20, s = await sample(T(pc));
    if (prevF) for (const k of RIGID) {
      const d = dev(prevF.s[k].m, s[k].m, ptsOf[k]);
      if (d > 0.6) jumps.push({ pc, k, d: +d.toFixed(2), op: +Math.min(hideOp(prevF.s, k), hideOp(s, k)).toFixed(4) });
    }
    for (const k of ['st', 'bd', 'gb', 'gf', 'rb', 'rf', 'gt', 'rt']) if (s[k].op !== 1) opChange.add(k);
    const sum = s.a.op + s.bb.op; if (sum < minBill.v) minBill = { v: +sum.toFixed(3), pc }; if (sum > maxBill.v) maxBill = { v: +sum.toFixed(3), pc };
    if (sum < 0.3) billLow += DUR / 2000; if (Math.min(s.a.op, s.bb.op) > 0.15) billDouble += DUR / 2000;
    prevF = { s };
  }
  const visibleJumps = jumps.filter((j) => j.op > 1e-3);

  // ---------------------------------------------------------------- 60 Hz pass: speed, stillness, peek, clearance
  const F = Math.round(DUR / 1000 * 60), PX = 300 / 320;
  let prev = null; const speed = {}; let stillMove = 0, stillAll = 0;
  const peek = { byReceiver: { v: -Infinity }, byGiver: { v: -Infinity }, contactReceiver: { v: -Infinity }, contactGiver: { v: -Infinity } };
  let thumbClearPc = null, recvThumbOnPc = null;
  // signed gap: distance from the hand outline to the bill rectangle; negative = depth of the deepest point inside it
  const depth = (q) => Math.min(q[0] - B.x, B.x + B.w - q[0], q[1] - B.y, B.y + B.h - q[1]);
  const gapAt = (s, handKey, billKey) => { const Mi = inv(s[billKey].m); let m = Infinity; for (const p of ptsOf[handKey]) { const q = ap(Mi, ap(s[handKey].m, p)); m = Math.min(m, inRect(q) ? -depth(q) : rectDist(q)); } return m; };
  const cuff = { giverMinX: Infinity, receiverMaxX: -Infinity };
  for (let f = 0; f <= F; f++) {
    const t = Math.min(f / 60 * 1000, DUR - 1e-4), pc = t / DUR * 100;
    const s = await sample(t);
    if (prev) {
      let moved = false, opch = false;
      for (const k of ['gb', 'rb', 'a', 'bb', 'gt', 'rt']) {
        const vis = hideOp(s, k) > 0 && hideOp(prev, k) > 0;
        const d = dev(prev[k].m, s[k].m, ptsOf[k]) * PX;
        if (vis && (!speed[k] || d > speed[k].v)) speed[k] = { v: +d.toFixed(3), pc: +pc.toFixed(1) };
        if (vis && d / PX > 0.002) moved = true;
      }
      for (const k of ['a', 'bb', 'gp', 'rp']) if (Math.abs(prev[k].op - s[k].op) > 1e-3) opch = true;
      if (!moved) stillMove++; if (!moved && !opch) stillAll++;
    }
    // finger peek above the top edge of every bill that is visible
    for (const bk of ['a', 'bb']) {
      if (s[bk].op < 0.05) continue; const Mi = inv(s[bk].m);
      for (const [handKey, slot] of [['rb', 'byReceiver'], ['gb', 'byGiver']]) for (const p of ptsOf[handKey]) {
        const q = ap(Mi, ap(s[handKey].m, p));
        if (q[0] > B.x + 0.5 && q[0] < B.x + B.w - 0.5 && q[1] < B.y + 4) {
          const e = B.y - q[1]; if (e > peek[slot].v) peek[slot] = { v: +e.toFixed(3), pc: +pc.toFixed(1), bill: bk };
          const cs = slot === 'byGiver' ? 'contactGiver' : 'contactReceiver';
          if (pc >= P.rp1 && pc <= P.t0 && e > peek[cs].v) peek[cs] = { v: +e.toFixed(3), pc: +pc.toFixed(1), bill: bk };
        }
      }
    }
    if (pc >= P.gp0 && pc < P.bi0 && thumbClearPc === null) {
      const Mi = inv(s.a.m); if (!ptsOf.gt.some((p) => inRect(ap(Mi, ap(s.gt.m, p))))) thumbClearPc = +pc.toFixed(1);
    }
    if (recvThumbOnPc === null && pc < P.t0) {
      const Mi = inv(s.bb.m); if (ptsOf.rt.some((p) => inRect(ap(Mi, ap(s.rt.m, p))))) recvThumbOnPc = +pc.toFixed(1);
    }
    for (const p of CUFF.giverCuffVisible) { const x = ap(s.gf.m, p)[0]; if (x < cuff.giverMinX) { cuff.giverMinX = x; cuff.gAt = +pc.toFixed(1); } }
    for (const p of CUFF.receiverCuff) { const x = ap(s.rf.m, p)[0]; if (x > cuff.receiverMaxX) { cuff.receiverMaxX = x; cuff.rAt = +pc.toFixed(1); } }
    prev = s;
  }
  const sRest = await sample(0), sEnd = await sample(T(P.ro0 - 0.5));
  const gaps = { rest_receiverFingers_to_billB: +gapAt(sRest, 'rb', 'bb').toFixed(2), end_giverFingers_to_billA: +gapAt(sEnd, 'gb', 'a').toFixed(2) };
  // pixel identity of the wrap and of the A/B relay (screenshots, day and night, 2x DPR)
  const pix = {};
  for (const theme of ['dia', 'noche']) {
    const pp = await br.newPage({ viewport: { width: 960, height: 540 }, deviceScaleFactor: 2 });
    await pp.goto('file://' + html); await pp.evaluate((th) => { document.body.dataset.hsaTheme = th; document.body.style.background = th === 'noche' ? '#0C0A09' : '#F4F1EA'; document.getAnimations().forEach((a) => a.pause()); }, theme);
    const shot = async (t) => { await pp.evaluate((t) => document.getAnimations().forEach((a) => { a.currentTime = t; }), t); await pp.waitForTimeout(60); return pp.screenshot(); };
    const i0 = await shot(0), i1 = await shot(DUR - 1e-4);
    const r0 = await shot(T(P.swap) - 1), r1 = await shot(T(SWB) + 1);
    pix[theme] = { wrap: i0.equals(i1), relay: r0.equals(r1) }; await pp.close();
  }
  const opAnimated = await pg.evaluate(() => {
    const out = [];
    for (const el of document.querySelectorAll('svg.hsa-ce *')) for (const a of el.getAnimations()) { const kf = a.effect.getKeyframes(); if (kf.some((k) => 'opacity' in k)) out.push((el.getAttribute('class') || el.tagName) + ':' + a.animationName); }
    return out;
  });
  // ---------------------------------------------------------------- prefers-reduced-motion: the markup pose
  const pr = await br.newPage({ viewport: { width: 960, height: 540 } });
  await pr.emulateMedia({ reducedMotion: 'reduce' }); await pr.goto('file://' + html); await pr.waitForTimeout(100);
  const rm = await pr.evaluate((SEL) => {
    const root = document.querySelector('svg.hsa-ce'); const R = root.getScreenCTM().inverse(); const o = { running: document.getAnimations().length };
    for (const [k, s] of Object.entries(SEL)) {
      const el = document.querySelector(s); const m = R.multiply(el.getScreenCTM()); const pm = R.multiply(el.parentNode.getScreenCTM());
      const rel = pm.inverse().multiply(m);   // own transform relative to the parent (identity = markup pose)
      o[k] = { identity: Math.abs(rel.a - 1) + Math.abs(rel.b) + Math.abs(rel.c) + Math.abs(rel.d - 1) + Math.abs(rel.e) + Math.abs(rel.f) < 1e-9, op: +getComputedStyle(el).opacity };
    }
    return o;
  }, SEL);
  await br.close(); fs.unlinkSync(html);

  const ok = (v) => (v < 0.05 ? 'OK' : 'FAIL');
  const ms = (pc) => Math.round(pc / 100 * DUR);
  console.log(`animations running: ${nAnim}; samples: ${pcs.length} (every 0.5 % + phase edges) + 2001 (every 0.05 %) + ${F + 1} (60 Hz)`);
  console.log('\nLOCK (max deviation, SVG units; must be < 0.05)');
  console.log(`  bill A vs giver,    giver-held 0-${P.t0} % and ${JB}-100 %: ${lock.giverHeld.toExponential(2)} u  ${ok(lock.giverHeld)}  (worst at ${lockAt.giverHeld ?? '-'} %)`);
  console.log(`  bill A vs receiver, receiver-held ${P.t0}-${P.jump} %       : ${lock.receiverHeld.toExponential(2)} u  ${ok(lock.receiverHeld)}  (worst at ${lockAt.receiverHeld ?? '-'} %)`);
  console.log(`  bill A vs both,     contact ${P.rp1}-${P.t0} %              : ${lock.contactBoth.toExponential(2)} u  ${ok(lock.contactBoth)}`);
  console.log(`  bill B vs giver,    whole loop                     : ${lock.billB.toExponential(2)} u  ${ok(lock.billB)}`);
  console.log(`  bill A vs bill B,   0-${P.t0} % (relay at ${P.swap} %)       : ${lock.relay.toExponential(2)} u  ${ok(lock.relay)}`);
  console.log(`  giver --back vs --front                          : ${lock.layersG.toExponential(2)} u  ${ok(lock.layersG)}`);
  console.log(`  receiver --back vs --front                       : ${lock.layersR.toExponential(2)} u  ${ok(lock.layersR)}`);
  console.log(`  giver thumb layer pivot fixed on the hand         : ${lock.thumbPivotG.toExponential(2)} u  ${ok(lock.thumbPivotG)}`);
  console.log(`  receiver thumb layer pivot fixed on the hand      : ${lock.thumbPivotR.toExponential(2)} u  ${ok(lock.thumbPivotR)}`);
  console.log('\nSEAM 0 % vs 100 % (computed)');
  for (const [k, v] of Object.entries(seam)) console.log(`  ${k.padEnd(4)} ${JSON.stringify(v)}`);
  console.log(`  pixel-identical: wrap (0 % == 100 %) day ${pix.dia.wrap}, night ${pix.noche.wrap}; A/B relay (just before == just after ${P.swap} %) day ${pix.dia.relay}, night ${pix.noche.relay}`);
  console.log(`  declared 0%/100% keyframe differences: ${declDiff.length ? '\n    ' + declDiff.join('\n    ') : 'none'}`);
  console.log(`\nJUMPS (> 0.6 u between 2.8 ms samples): ${jumps.length} total, ${visibleJumps.length} while the jumping group is visible ${visibleJumps.length ? JSON.stringify(visibleJumps.slice(0, 8)) : ''}`);
  console.log(`  at: ${jumps.map((j) => `${j.k}@${j.pc}%(op ${j.op})`).join(', ') || '-'}`);
  console.log('\nOPACITY');
  console.log(`  groups whose opacity is ever != 1 among stage/halo/hands/thumbs: ${[...opChange].join(', ') || 'none'}`);
  console.log(`  bill opacity A + B: min ${minBill.v} at ${minBill.pc} %, max ${maxBill.v} at ${maxBill.pc} %; below .3 for ${Math.round(billLow)} ms (limit 150); both bills > .15 for ${Math.round(billDouble)} ms (no double exposure: limit 0)`);
  console.log(`  opacity animations: ${opAnimated.join(', ')}`);
  console.log('\nQA');
  console.log('  peak speed px/frame @300 px, 60 Hz (limit 6):', JSON.stringify(speed));
  console.log(`  still (no movement): ${(stillMove / F * 100).toFixed(1)} %   fully static (no movement, no opacity change): ${(stillAll / F * 100).toFixed(1)} %`);
  console.log('  finger peek above the visible bill\'s top edge (u; >0 = finger visible above the edge, <0 = closest margin under it; contact* = during the hold, must be <= -1.5):', JSON.stringify(peek));
  console.log('  gaps free-hand fingers <-> bill (u, <0 = overlap):', JSON.stringify(gaps));
  console.log(`  receiver thumb first over the bill at ${recvThumbOnPc} %; giver thumb fully off the bill at ${thumbClearPc} % (${thumbClearPc !== null ? ms(thumbClearPc - P.gp0) : '-'} ms after release)`);
  console.log(`  cuffs vs edge fade (${PIV.fade} u): giver shirt-cuff min x ${cuff.giverMinX.toFixed(2)} at ${cuff.gAt} % (must be >= ${PIV.fade}), receiver rib-cuff max x ${cuff.receiverMaxX.toFixed(2)} at ${cuff.rAt} % (must be <= ${320 - PIV.fade})`);
  const rmOk = rm.running === 0 && RIGID.every((k) => rm[k].identity) && rm.st.op === 1 && rm.a.op === 1 && rm.bb.op === 0 && rm.gp.op === 1 && rm.rp.op === 1;
  console.log(`  prefers-reduced-motion: ${rm.running} animations, all groups at the markup (contact) pose: ${RIGID.every((k) => rm[k].identity)}, bill A op ${rm.a.op}, bill B op ${rm.bb.op}, dents ${rm.gp.op}/${rm.rp.op} -> ${rmOk ? 'OK' : 'FAIL'}`);
  const cuffOk = cuff.giverMinX >= PIV.fade && cuff.receiverMaxX <= 320 - PIV.fade;
  const gapOk = gaps.rest_receiverFingers_to_billB >= 5 && gaps.end_giverFingers_to_billA >= 5;
  const pass = rmOk && cuffOk && gapOk && pix.dia.wrap && pix.noche.wrap && pix.dia.relay && pix.noche.relay && visibleJumps.length === 0 && opChange.size === 0
    && billLow <= 150 && billDouble === 0 && maxBill.v <= 1.0001 && Object.values(lock).every((v) => v < 0.05) && Object.values(seam).every((v) => v.ok) && declDiff.length === 0
    && peek.byReceiver.v < 0 && peek.byGiver.v < 0 && peek.contactGiver.v <= -1.5 && peek.contactReceiver.v <= -1.5 && Object.values(speed).every((v) => v.v < 6);
  console.log(`\nRESULT: ${pass ? 'PASS' : 'FAIL'}${gapOk ? '' : ' (free-hand gap < 5 u)'}${cuffOk ? '' : ' (cuff in the fade)'}`);
  process.exit(pass ? 0 : 1);
})();
