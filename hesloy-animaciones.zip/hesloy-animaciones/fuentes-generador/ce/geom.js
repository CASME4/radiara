// Small geometry helpers to build smooth organic outlines from scratch.
const r = (n) => Math.round(n * 10) / 10;
function add(a, b) { return [a[0] + b[0], a[1] + b[1]]; }
function sub(a, b) { return [a[0] - b[0], a[1] - b[1]]; }
function mul(a, k) { return [a[0] * k, a[1] * k]; }
function len(a) { return Math.hypot(a[0], a[1]); }
function norm(a) { const l = len(a) || 1; return [a[0] / l, a[1] / l]; }
function lerp(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]; }

// compact number formatting: 1 decimal, no leading zero
function fmt(n) {
  let v = Math.round(n * 10) / 10; if (Object.is(v, -0)) v = 0;
  let t = v.toString();
  if (t.startsWith('0.')) t = t.slice(1); else if (t.startsWith('-0.')) t = '-' + t.slice(2);
  return t;
}
function joinNums(arr) {
  let out = '';
  for (const n of arr) { const t = fmt(n); if (out && !t.startsWith('-') && !(t.startsWith('.') && /\.\d*$/.test(out.split(/[ \-]/).pop()))) out += ' '; out += t; }
  return out;
}
// Ramer-Douglas-Peucker simplification (keeps endpoints)
function rdp(pts, eps) {
  if (pts.length < 3) return pts;
  const [a, b] = [pts[0], pts[pts.length - 1]];
  let idx = -1, dmax = 0;
  const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1e-9;
  for (let i = 1; i < pts.length - 1; i++) {
    const d = Math.abs((pts[i][0] - a[0]) * dy - (pts[i][1] - a[1]) * dx) / L;
    if (d > dmax) { dmax = d; idx = i; }
  }
  if (dmax <= eps) return [a, b];
  return [...rdp(pts.slice(0, idx + 1), eps).slice(0, -1), ...rdp(pts.slice(idx), eps)];
}
let SIMPLIFY = 0.07;
function setSimplify(e) { SIMPLIFY = e; }
// Catmull-Rom -> cubic bezier path (relative commands, compact)
function crPath(ptsIn, closed = true, tension = 1) {
  let pts = ptsIn;
  if (SIMPLIFY > 0 && pts.length > 6) {
    if (closed) { const half = Math.floor(pts.length / 2); pts = [...rdp(pts.slice(0, half + 1), SIMPLIFY).slice(0, -1), ...rdp([...pts.slice(half), pts[0]], SIMPLIFY).slice(0, -1)]; }
    else pts = rdp(pts, SIMPLIFY);
  }
  const n = pts.length;
  const P = (i) => closed ? pts[(i + n) % n] : pts[Math.max(0, Math.min(n - 1, i))];
  // work in rounded absolute coords to avoid drift
  const R = (p) => [Math.round(p[0] * 10) / 10, Math.round(p[1] * 10) / 10];
  let cur = R(pts[0]);
  let d = 'M' + joinNums(cur);
  const segs = closed ? n : n - 1;
  let first = true;
  for (let i = 0; i < segs; i++) {
    const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    const c1 = R(add(p1, mul(sub(p2, p0), tension / 6)));
    const c2 = R(sub(p2, mul(sub(p3, p1), tension / 6)));
    const e = R(p2);
    d += (first ? 'c' : ' ') + joinNums([c1[0] - cur[0], c1[1] - cur[1], c2[0] - cur[0], c2[1] - cur[1], e[0] - cur[0], e[1] - cur[1]]);
    first = false; cur = e;
  }
  return d.replace(/ (-)/g, '$1') + (closed ? 'z' : '');
}
// sample a catmull-rom open curve through pts
function crSample(pts, perSeg = 12) {
  const n = pts.length, out = [];
  const P = (i) => pts[Math.max(0, Math.min(n - 1, i))];
  for (let i = 0; i < n - 1; i++) {
    const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    for (let s = 0; s < perSeg; s++) {
      const t = s / perSeg, t2 = t * t, t3 = t2 * t;
      const x = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3);
      const y = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3);
      out.push({ p: [x, y], seg: i, t });
    }
  }
  out.push({ p: pts[n - 1], seg: n - 2, t: 1 });
  return out;
}
// Finger/limb outline: centerline joints + half widths at joints.
// opts.bulge: extra width at joints vs mid-segments; opts.tipRound: 0..1
function limb(joints, hw, opts = {}) {
  const { bulge = 0.06, perSeg = 6, tipSquash = 0.85, baseExtend = 0, keep = 1 } = opts; const perSegU = Math.min(perSeg, 5);
  const S = crSample(joints, perSegU);
  const left = [], right = [];
  for (let k = 0; k < S.length; k++) {
    const { p, seg, t } = S[k];
    const a = S[Math.max(0, k - 1)].p, b = S[Math.min(S.length - 1, k + 1)].p;
    const tan = norm(sub(b, a));
    const nrm = [-tan[1], tan[0]];
    let w = hw[seg] + (hw[seg + 1] - hw[seg]) * t;
    // narrower mid-segment, fuller at joints
    w *= 1 - bulge * Math.pow(Math.sin(Math.PI * t), 2);
    left.push(add(p, mul(nrm, w)));
    right.push(sub(p, mul(nrm, w)));
  }
  // tip cap
  const end = S[S.length - 1].p, prev = S[S.length - 2].p;
  const tan = norm(sub(end, prev)); const nrm = [-tan[1], tan[0]];
  const wt = hw[hw.length - 1];
  const cap = [];
  for (let i = 1; i < 6; i++) {
    const ang = Math.PI * i / 6; // from left normal to right normal through tangent
    const v = add(mul(nrm, Math.cos(ang) * wt), mul(tan, Math.sin(ang) * wt * tipSquash));
    cap.push(add(end, v));
  }
  const pts = [...left, ...cap, ...right.reverse()];
  return pts;
}
function polyPath(pts) { return crPath(pts, true, 1); }
function rot(p, deg, c = [0, 0]) {
  const a = deg * Math.PI / 180, s = Math.sin(a), co = Math.cos(a);
  const x = p[0] - c[0], y = p[1] - c[1];
  return [c[0] + x * co - y * s, c[1] + x * s + y * co];
}
module.exports = { setSimplify, fmt, r, add, sub, mul, len, norm, lerp, crPath, crSample, limb, polyPath, rot };
// Tapered stroke as a filled shape: width profile w0 -> wmax -> w1 along a smooth curve.
function taper(pts, wmax, o = {}) {
  const { w0 = 0.04, w1 = 0.04, perSeg = 5, peak = 0.5, pow = 0.8 } = o;
  const S = crSampleExport(pts, perSeg);
  const n = S.length; const L = [], Rr = [];
  for (let k = 0; k < n; k++) {
    const t = k / (n - 1);
    const a = S[Math.max(0, k - 1)], b = S[Math.min(n - 1, k + 1)];
    const tan = norm(sub(b, a)); const nr = [-tan[1], tan[0]];
    const u = t < peak ? t / peak : (1 - t) / (1 - peak);
    const prof = Math.pow(Math.sin(Math.PI / 2 * Math.max(0, Math.min(1, u))), pow);
    const base = t < peak ? w0 : w1;
    const w = (base + (wmax - base) * prof) / 2;
    L.push(add(S[k], mul(nr, w))); Rr.push(sub(S[k], mul(nr, w)));
  }
  return [...L, ...Rr.reverse()];
}
function crSampleExport(pts, perSeg) { return crSample(pts, perSeg).map((s) => s.p); }
function ellipsePts(c, rx, ry, ang = 0, n = 24) {
  const out = [];
  for (let i = 0; i < n; i++) { const t = i / n * Math.PI * 2; out.push(add(c, rot([Math.cos(t) * rx, Math.sin(t) * ry], ang))); }
  return out;
}
function offsetPts(pts, d) { return pts.map((p) => add(p, d)); }
Object.assign(module.exports, { taper, ellipsePts, offsetPts, crSampleExport });
