const G = require('./geom');
const f1 = (n) => G.fmt(n);
const v = (name, fb) => `var(--${name},${fb})`;
const fillv = (name, fb, extra = '') => `style="fill:${v(name, fb)}${extra}"`;
const strokev = (name, fb, extra = '') => `style="stroke:${v(name, fb)}${extra}"`;
const stop = (o, name, fb, op) => `<stop offset="${o}" style="stop-color:${v(name, fb)}${op !== undefined ? `;stop-opacity:${op}` : ''}"/>`;
// Didone-like Q glyph built from geometry (no fonts)
function qGlyph(cx, cy, s, style) {
  const outer = G.ellipsePts([cx, cy], 5.4 * s, 6.4 * s, 0, 40);
  const inner = G.ellipsePts([cx + 0.35 * s, cy - 0.1 * s], 3.55 * s, 5.35 * s, 0, 40).reverse();
  const tail = G.taper([[cx - 0.6 * s, cy + 4.6 * s], [cx + 1.6 * s, cy + 6.6 * s], [cx + 4.4 * s, cy + 8.2 * s], [cx + 6.6 * s, cy + 8.0 * s]], 1.35 * s, { w0: 0.3 * s, w1: 0.2 * s, peak: 0.35 });
  return `<path d="${G.crPath(outer)}${G.crPath(inner)}" fill-rule="evenodd" ${style}/><path d="${G.crPath(tail)}" ${style}/>`;
}
module.exports = { f1, v, fillv, strokev, stop, qGlyph };
// Merge duplicate style attributes in each tag; for other duplicates keep the first (as HTML parsing does).
function sanitize(svg) {
  return svg.replace(/<([a-zA-Z]+)((?:\s+[a-zA-Z:-]+="[^"]*")*)\s*(\/?)>/g, (m, tag, attrs, selfc) => {
    const list = [...attrs.matchAll(/\s+([a-zA-Z:-]+)="([^"]*)"/g)].map(a => [a[1], a[2]]);
    const out = []; const seen = new Map();
    for (const [k, val] of list) {
      if (seen.has(k)) { if (k === 'style') out[seen.get(k)][1] += ';' + val; continue; }
      seen.set(k, out.length); out.push([k, val]);
    }
    return `<${tag}${out.map(([k, val]) => ` ${k}="${val}"`).join('')}${selfc ? '/' : ''}>`;
  });
}
module.exports.sanitize = sanitize;
// Add presentation-attribute fallbacks (fill="#hex" …) derived from style="fill:var(--x,#hex)".
// Keeps the art correct where inline styles or CSS variables are unavailable (strict CSP, editors).
function addFallbacks(svg) {
  const props = ['fill', 'stroke', 'stop-color', 'opacity', 'fill-opacity', 'stroke-opacity', 'stop-opacity'];
  return svg.replace(/<([a-zA-Z]+)((?:\s+[a-zA-Z:-]+="[^"]*")*)\s*(\/?)>/g, (m, tag, attrs, selfc) => {
    const st = /\sstyle="([^"]*)"/.exec(attrs); if (!st) return m;
    let extra = '';
    for (const decl of st[1].split(';')) {
      const i = decl.indexOf(':'); if (i < 0) continue;
      const k = decl.slice(0, i).trim(), val = decl.slice(i + 1).trim();
      if (!props.includes(k)) continue;
      if (new RegExp(`\\s${k}="`).test(attrs) || new RegExp(`\\s${k}="`).test(extra)) continue;
      const fb = /^var\(--[\w-]+,\s*([^)]+)\)$/.exec(val);
      const plain = fb ? fb[1].trim() : (/^var\(/.test(val) ? null : val);
      if (plain) extra += ` ${k}="${plain}"`;
    }
    return `<${tag}${attrs}${extra}${selfc ? '/' : ''}>`;
  });
}
module.exports.addFallbacks = addFallbacks;
