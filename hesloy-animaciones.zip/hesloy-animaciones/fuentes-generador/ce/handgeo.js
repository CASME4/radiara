// Canonical hand A (giver) used by build-cash.js (contra-entrega).
// Frame: RIGHT hand, palm to viewer, fingers up (-y), thumb on +x, 1 unit ~ 2 mm, wrist crease at y = 54.
// Target = mean adult male hand: hand length (wrist crease y=54 -> middle tip) ~94 u (188 mm),
// metacarpal breadth ~42 u (84 mm), breadth/length 0.45, palm/hand 0.60.
// Joint centres: MoBL/MyoSuite skeleton (scaled x1.072, mm->u x0.5) for the MCP levels and P1.
//
// FINGERS are BUILT here (not hand-typed) from:
//   - fixed MCP centres and the apparent P1 (unchanged from the anatomy research);
//   - finger half-widths (base, PIP, DIP, tip) = research widths x 0.88 (slenderness len/baseWidth ~3.6-3.75,
//     pinky ~3.2: the round-1/2 fingers read as sausages);
//   - a RELAXED FLEXION CASCADE: MCP 5 deg, PIP = DIP = 6 / 9 / 13 / 18 deg (index / middle / ring / pinky).
//     In palm view a flexed phalanx is foreshortened by cos(cumulative flexion); the true P2/P3 lengths are solved
//     so that the APPARENT crease-to-tip lengths are index 34.5 / middle 37 / ring 35 / pinky 28 u
//     (ratios to the middle 0.93 / 0.95 / 0.76, 2D:4D 0.986);
//   - in-plane CONVERGENCE: each P1 is tilted so neighbours touch at the PIP (overlap 0.15 u), then P2 and P3 curl
//     towards the middle/ring axis (pinky 4 + 7 deg, ring 2 + 4, middle .6 + 1.2, index -.8 - 1.5), so the
//     ulnar fingers bow radially and the tips converge (axis tilts about -2 / +2 / +6 / +10 deg). Small lens gaps
//     open distal to the PIPs, as on a real relaxed hand.
//   - fingertip pulp opacity grows with flexion (the pad turns towards the viewer).
// Everything here stays behind the bill at contact (the bill's top edge hides the index; see check-lock.js).
// Hand B (receiver) is derived from this file in handgeo-b.js (a different person: broader, shorter digits).
const D = Math.PI / 180;
const MCP = { pinky: [-15.4, 13.2], ring: [-7.2, 8.8], middle: [2.2, 8.1], index: [11.8, 8.0] };
const P1APP = { pinky: 18.7, ring: 21.9, middle: 23.0, index: 21.8 };          // apparent MCP -> PIP (unchanged)
const W = {                                                                     // half-widths base / PIP / DIP / tip
  pinky: [4.05, 3.75, 3.12, 2.86], ring: [4.66, 4.27, 3.52, 3.21], middle: [4.93, 4.49, 3.74, 3.39], index: [4.8, 4.36, 3.65, 3.3],
};
const FLEX = { pinky: [5, 18, 18], ring: [5, 13, 13], middle: [5, 9, 9], index: [5, 6, 6] };   // MCP, PIP, DIP (deg)
const RATIO = { pinky: [0.58, 0.56], ring: [0.62, 0.52], middle: [0.66, 0.5], index: [0.6, 0.5] };   // true P2, P3(to skin tip) / P1 shape
const TARGET = { pinky: 28, ring: 35, middle: 37, index: 34.5 };               // apparent crease -> skin tip
const CURL = { pinky: [4, 7], ring: [2, 4], middle: [0.6, 1.2], index: [-0.8, -1.5] };   // in-plane, at PIP and DIP (+ = radial)
const PULP = { pinky: 0.4, ring: 0.36, middle: 0.3, index: 0.26 };
const MID_TILT = 1.2;      // middle P1 in-plane tilt (deg, + = radial); the others are solved from the PIP contact
const OVERLAP = 0.15;

const PALM_A = [
  [-14.0, 64], [-14.4, 56], [-16.5, 49.5], [-18.7, 42.5], [-20.2, 34.5], [-20.6, 26], [-21.2, 18], [-21.1, 11.5],
  [-20.1, 6.6], [-18.0, 4.6], [-15.2, 3.4], [-11.4, 1.4], [-7.0, -0.9], [-2.4, -2.1], [2.4, -2.8], [7.2, -2.4],
  // radial-distal corner (index MCP) tucked under the thumb's dorsal border (no parallel double contour); the
  // radial border by the wrist stays inside the thenar outline (it must never form the silhouette there)
  [11.8, -1.7], [15.2, 0.4], [17.2, 3.8], [18.6, 9.0], [20.2, 16], [21.0, 24], [20.0, 33], [15.8, 43.5], [13.8, 50],
  [13.2, 56], [13.0, 64], [0, 65.5],
];
// builder: sx scales the palm and the MCP x positions (a broader hand), ws the finger widths, sd the apparent
// crease -> tip lengths (shorter digits). Hand A = defaults; hand B (handgeo-b.js) = another person.
function buildFingers({ sx = 1, ws = 1, sd = 1 } = {}) {
let palm = PALM_A.map((p) => [+(p[0] * sx).toFixed(2), p[1]]);
const MCPx = Object.fromEntries(Object.entries(MCP).map(([k, p]) => [k, [+(p[0] * sx).toFixed(2), p[1]]]));
const Wx = Object.fromEntries(Object.entries(W).map(([k, w]) => [k, w.map((v) => +(v * ws).toFixed(2))]));
const TGT = Object.fromEntries(Object.entries(TARGET).map(([k, v]) => [k, v * sd]));
function palmTop(x) {
  let best = Infinity;
  for (let i = 0; i < palm.length; i++) {
    const a = palm[i], b = palm[(i + 1) % palm.length];
    if ((a[0] - x) * (b[0] - x) <= 0 && a[0] !== b[0]) { const y = a[1] + (x - a[0]) / (b[0] - a[0]) * (b[1] - a[1]); if (y < best) best = y; }
  }
  return best;
}
const dirOf = (deg) => [Math.sin(deg * D), -Math.cos(deg * D)];   // in-plane direction: 0 = up, + = towards +x (radial)
const r2 = (p) => p.map((n) => +n.toFixed(2));
function build(k, tilt) {
  const m = MCPx[k], f = FLEX[k], c = CURL[k], w = Wx[k];
  const pip = [m[0] + dirOf(tilt)[0] * P1APP[k], m[1] + dirOf(tilt)[1] * P1APP[k]];
  const L1 = P1APP[k] / Math.cos(f[0] * D);
  const cos2 = Math.cos((f[0] + f[1]) * D), cos3 = Math.cos((f[0] + f[1] + f[2]) * D);
  const a2 = tilt + c[0], a3 = tilt + c[0] + c[1];
  // solve the true-length scale s (P2 = s*RATIO[0]*L1, P3 = s*RATIO[1]*L1) for the apparent crease -> tip target
  const tipFor = (s) => {
    const p2 = s * RATIO[k][0] * L1 * cos2, p3 = s * RATIO[k][1] * L1 * cos3;
    const dip = [pip[0] + dirOf(a2)[0] * p2, pip[1] + dirOf(a2)[1] * p2];
    const tip = [dip[0] + dirOf(a3)[0] * p3, dip[1] + dirOf(a3)[1] * p3];
    return { dip, tip, p3 };
  };
  const crease = palmTop(m[0] + (pip[0] - m[0]) * 0.3);
  let lo = 0.5, hi = 1.6;
  for (let i = 0; i < 50; i++) { const s = (lo + hi) / 2; const { tip } = tipFor(s); if (crease - tip[1] < TGT[k]) lo = s; else hi = s; }
  const { dip, tip, p3 } = tipFor((lo + hi) / 2);
  const cap = [dip[0] + dirOf(a3)[0] * (p3 - w[3]), dip[1] + dirOf(a3)[1] * (p3 - w[3])];   // tip-cap centre (tipSquash 1)
  return { j: [m, pip, dip, cap].map(r2), w, pulp: PULP[k] };
}
// P1 tilts: neighbours touch at the PIP. Distance between PIP centres = w1a + w1b - OVERLAP (fingers ~parallel there).
function solveTilt(k, nb, nbTilt, side) {
  const nbPip = build(nb, nbTilt).j[1];
  const want = Wx[k][1] + Wx[nb][1] - OVERLAP;
  let lo = -15, hi = 15;
  for (let i = 0; i < 60; i++) {
    const t = (lo + hi) / 2; const p = build(k, t).j[1];
    const d = side * (p[0] - nbPip[0]);                                   // side = +1: k lies on the +x side of nb
    if ((d > want) === (side > 0)) hi = t; else lo = t;
  }
  return (lo + hi) / 2;
}
const TILT = { middle: MID_TILT };
TILT.index = solveTilt('index', 'middle', TILT.middle, 1);
TILT.ring = solveTilt('ring', 'middle', TILT.middle, -1);
TILT.pinky = solveTilt('pinky', 'ring', TILT.ring, -1);
const fingers = {};
for (const k of ['pinky', 'ring', 'middle', 'index']) fingers[k] = build(k, TILT[k]);
// ulnar-distal palm corner: blend it into the pinky's ulnar edge with a soft concave fillet (the palm is widest at
// the 5th MCP head, then turns into the little finger without a notch, whatever the finger width / tilt)
{
  const f = fingers.pinky, a = f.j[0], b = f.j[1], d = [b[0] - a[0], b[1] - a[1]], L = Math.hypot(...d), u = [d[0] / L, d[1] / L];
  const nU = [u[1], -u[0]];                                                          // towards -x (ulnar)
  const p0 = [a[0] + nU[0] * f.w[0], a[1] + nU[1] * f.w[0]], p1 = [b[0] + nU[0] * f.w[1], b[1] + nU[1] * f.w[1]];
  const edgeX = (y) => p0[0] + (y - p0[1]) / (p1[1] - p0[1]) * (p1[0] - p0[0]);
  for (const [i, off] of [[8, 0.9], [9, -0.6]]) palm[i] = [+(edgeX(palm[i][1]) - off).toFixed(2), palm[i][1]];
}
return { palm, fingers, fingerTilt: Object.fromEntries(Object.entries(TILT).map(([k, t]) => [k, +t.toFixed(2)])) };
}
const FA = buildFingers();

module.exports = {
  palm: FA.palm,
  forearm: [[-13.4, 50], [-14.4, 80], [-16.6, 132], [16.6, 132], [14.6, 80], [13.4, 50]],
  // j = [MCP centre, PIP centre, DIP centre, tip-cap centre]; skin tip = j[3] + tipSquash*w[3] along the axis
  // pulp = opacity of the lifted fingertip pad (flexed fingers show more of it)
  fingers: FA.fingers,
  fingerTilt: FA.fingerTilt,
  tipSquash: 1.0,
  // thumb: [MCP, IP, tip-cap centre]; CMC (not drawn as a joint) at [13.7, 37.9]
  thumbCMC: [13.7, 37.9],
  // pivot of the rigid thumb layer (abduction): base of the thenar eminence, hidden under the cuff edge
  thumbPivot: [13.8, 57.5],
  thumb: { j: [[20.0, 21.5], [14.0, 6.8], [7.6, -2.6]], w: [5.9, 4.95, 4.55], tipSquash: 0.9 },
  thenarOuter: [[13.6, 64], [13.8, 56], [14.6, 50], [16.4, 45], [19.2, 39.5], [21.6, 34], [23.4, 29], [24.6, 24]],
  thenarCrease: [[14.6, 24.4], [11.6, 27.4], [8.6, 33.0], [6.4, 39.6], [5.2, 46.4], [5.0, 52.8], [5.4, 58.5], [6.2, 64.5]],
  nail: { at: 0.70, halfLen: 0.245, halfWid: 0.62, off: 0.16 },   // fractions of IP->skin-tip length / thumb width at nail
  // exactly three palmar creases are drawn: heart + head (below) and the life line (= thenarCrease)
  creases: {
    // distal transverse: from the ulnar border, nearly transverse, curving distally to end between index and middle
    heart: [[-20.4, 16.6], [-14.8, 14.8], [-9.0, 13.1], [-3.4, 11.2], [1.4, 8.8], [4.8, 5.8], [6.4, 3.0]],
    // proximal transverse: shares its radial origin with the life line (hidden under the thumb), oblique, stops short of the ulnar border
    head: [[17.6, 15.0], [12.4, 17.6], [6.4, 20.9], [0.4, 24.3], [-5.4, 27.7], [-10.2, 30.9]],
  },
  thenarLight: { c: [17.2, 34], rx: 5.6, ry: 12.5, rot: -18 },
};
module.exports.buildFingers = buildFingers;
if (require.main === module) console.log(JSON.stringify({ tilt: FA.fingerTilt, fingers: FA.fingers }, null, 0));
