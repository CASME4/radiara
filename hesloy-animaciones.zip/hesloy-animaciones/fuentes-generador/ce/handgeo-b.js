// Canonical hand B (receiver): a different person, derived from hand A (handgeo.js) so both stay anatomically
// consistent but never read as a mirrored copy.
//  - broader hand: palm outline, thenar, creases and finger MCP centres x 1.04 (metacarpal breadth ~43.9 u);
//  - digits rebuilt by the same builder (handgeo.buildFingers): 1.5 % shorter (apparent crease -> tip) and 3 %
//    slimmer than hand A, so the fingers stay slender (len/baseWidth 3.5-3.8) on the broader palm; the P1 tilts
//    are re-solved so the adducted fingers still touch at the PIP, which makes this hand converge a little more;
//  - thumb widths x 1.02 and thumb MCP at [20.4, 22.5] (a slightly lower, more abducted thumb base);
//  - distal transverse (heart) crease with more curve, ending at [5.2, 4.0];
//  - a slightly wider thumbnail (halfWid 0.66).
const A = require('./handgeo');
const SX = 1.04;
const cp = (o) => JSON.parse(JSON.stringify(o));
const sx = (p) => [+(p[0] * SX).toFixed(2), p[1]];
const B = cp(A);
const F = A.buildFingers({ sx: SX, ws: 0.97, sd: 0.985 });
B.palm = F.palm;
B.fingers = F.fingers;
B.fingerTilt = F.fingerTilt;
B.thenarOuter = A.thenarOuter.map(sx);
B.thenarCrease = A.thenarCrease.map(sx);
B.thenarLight = { ...A.thenarLight, c: sx(A.thenarLight.c) };
B.thumbCMC = sx(A.thumbCMC);
B.thumbPivot = sx(A.thumbPivot);
B.thumb.w = A.thumb.w.map((w) => +(w * 1.02).toFixed(2));
B.thumb.j[0] = [20.4, 22.5];
B.creases.heart = [[-21.2, 17.4], [-15.6, 16.2], [-9.6, 14.6], [-4.0, 12.4], [0.6, 9.6], [3.8, 6.6], [5.2, 4.0]];
B.creases.head = A.creases.head.map(sx);
B.nail = { ...A.nail, halfWid: 0.66 };
delete B.buildFingers;
module.exports = B;
