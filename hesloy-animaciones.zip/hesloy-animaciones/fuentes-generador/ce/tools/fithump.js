// fit two cubic-beziers to h*sin(pi*e(t)) (hump that rides on the main easing e)
const { bez } = require('./bez');
const [x1, y1, x2, y2] = process.argv.slice(2, 6).map(Number); const e = bez(x1, y1, x2, y2);
let th = 0; for (let i = 0; i <= 4000; i++) { if (e(i / 4000) >= 0.5) { th = i / 4000; break; } }
const tgt1 = (u) => Math.sin(Math.PI * e(u * th));                 // 0 -> 1
const tgt2 = (u) => 1 - Math.sin(Math.PI * e(th + u * (1 - th)));  // 0 -> 1 (value = 1 - this)
function err(p, tgt) { const f = bez(...p); let m = 0; for (let i = 0; i <= 100; i++) { const u = i / 100; m = Math.max(m, Math.abs(f(u) - tgt(u))); } return m; }
function fit(tgt) {
  let best = [.4, 0, .6, 1], be = err(best, tgt);
  for (let it = 0; it < 6000; it++) {
    const sc = it < 3000 ? .2 : .03;
    const p = best.map((v, i) => i % 2 === 0 ? Math.min(1, Math.max(0, v + (Math.random() - .5) * sc)) : v + (Math.random() - .5) * sc);
    p[1] = Math.max(0, p[1]); p[3] = Math.min(1, p[3]);   // keep zero-ish velocity ends sane
    const q = err(p, tgt); if (q < be) { be = q; best = p; }
  }
  return { p: best.map((v) => +v.toFixed(2)), err: +err(best.map((v) => +v.toFixed(2)), tgt).toFixed(4) };
}
console.log(JSON.stringify({ tHalf: th, up: fit(tgt1), down: fit(tgt2) }));
