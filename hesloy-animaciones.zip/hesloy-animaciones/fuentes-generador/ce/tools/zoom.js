// node tools/zoom.js <svg> <css|-> <out.png> <timeMs> <dia|noche> <x> <y> <w> <h> [pxPerUnit=16]   (x,y,w,h in SVG units)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
(async () => {
  const [,, svgf, cssf, out, t, theme = 'dia', x, y, w, h, s = 16] = process.argv;
  const svg = fs.readFileSync(svgf, 'utf8'), css = cssf === '-' ? '' : fs.readFileSync(cssf, 'utf8');
  const bg = theme === 'noche' ? '#0C0A09' : '#F4F1EA', S = +s;
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: Math.ceil(+w * S), height: Math.ceil(+h * S) } });
  await p.setContent(`<!doctype html><style>${css} body{margin:0;background:${bg};overflow:hidden}</style><body data-hsa-theme="${theme}"><div style="position:absolute;left:${-x * S}px;top:${-y * S}px;width:${320 * S}px">${svg}</div></body>`);
  await p.waitForTimeout(150);
  await p.evaluate((t) => document.getAnimations().forEach(a => { a.pause(); a.currentTime = +t; }), t);
  await p.waitForTimeout(60);
  await p.screenshot({ path: out }); await b.close();
})();
