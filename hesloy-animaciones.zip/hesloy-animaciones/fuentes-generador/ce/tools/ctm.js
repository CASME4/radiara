const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
(async () => {
  const [,, svgf, cssf, ...ts] = process.argv;
  const svg = fs.readFileSync(svgf, 'utf8'), css = fs.readFileSync(cssf, 'utf8');
  const f = '/tmp/claude-0/-home-user-radiara/431e9b97-f2c9-57aa-9d92-7907f96c1c0e/scratchpad/variants/ce/tools/ctm.html';
  fs.writeFileSync(f, `<!doctype html><style>${css} body{margin:0}</style><body><div style="width:960px">${svg}</div></body>`);
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 960, height: 540 } });
  await p.goto('file://' + f);
  for (const t of ts) {
    const r = await p.evaluate((t) => { document.getAnimations().forEach((a) => { a.pause(); a.currentTime = +t; });
      const o = {}; for (const s of ['.ce-bill', '.ce-bill-b', '.ce-giver--back']) { const el = document.querySelector(s); const cs = getComputedStyle(el); const m = el.getCTM(); o[s] = [m.a, m.b, m.c, m.d, m.e, m.f].join(' ') + ' | ' + cs.translate + ' | ' + cs.rotate + ' | ' + cs.transform + ' | ' + cs.transformOrigin + ' | op ' + cs.opacity; }
      return o; }, t);
    console.log(t, JSON.stringify(r, null, 1));
  }
  await b.close(); fs.unlinkSync(f);
})();
