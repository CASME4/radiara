// renders the scene paused (class hsa-paused) at given ms values: only one complete bill may show
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'), path = require('path');
const DIR = path.resolve(__dirname, '..');
(async () => {
  const svg = fs.readFileSync(DIR + '/out/contra-entrega.svg', 'utf8'), css = fs.readFileSync(DIR + '/out/assembled.css', 'utf8');
  const T = (process.argv[2] || '4590,4700,4800,4900').split(',').map(Number);
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1000, height: 400 }, deviceScaleFactor: 1 });
  await p.setContent(`<!doctype html><style>${css} body{margin:0;background:#F4F1EA} .g{display:grid;grid-template-columns:repeat(4,240px);gap:8px;padding:8px}</style><body data-hsa-theme="dia"><div class="g">${T.map(() => `<div>${svg}</div>`).join('')}</div></body>`);
  await p.waitForTimeout(150);
  const ops = await p.evaluate((T) => [...document.querySelectorAll('svg.hsa-ce')].map((s, i) => { s.getAnimations({ subtree: true }).forEach((a) => { a.pause(); a.currentTime = T[i]; }); s.classList.add('hsa-paused');
    return [getComputedStyle(s.querySelector('.ce-bill')).opacity, getComputedStyle(s.querySelector('.ce-bill-b')).opacity]; }), T);
  console.log(JSON.stringify(ops));
  await p.screenshot({ path: DIR + '/renders/paused.png' }); await b.close();
})();
