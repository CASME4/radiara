// node tools/contours.js  -> tools/contours.json: outline points (final viewBox units, markup = contact pose) of
// each layer, traced from a transparent render of that layer alone at 8 px/u (alpha boundary, every 2nd pixel).
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'), path = require('path');
const DIR = path.resolve(__dirname, '..');
const svg = fs.readFileSync(DIR + '/out/contra-entrega.svg', 'utf8').replace('mask="url(#ce-fade)"', '');
const LAYERS = {
  'ce-giver--back': '.ce-giver--back', 'ce-receiver--back': '.ce-receiver--back',
  'ce-giver--front': '.ce-giver--front', 'ce-receiver--front': '.ce-receiver--front',
  'ce-giver-thumb': '.ce-giver--front .ce-thumb', 'ce-receiver-thumb': '.ce-receiver--front .ce-thumb',
};
(async () => {
  const b = await chromium.launch(); const out = {};
  for (const [name, sel] of Object.entries(LAYERS)) {
    const p = await b.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 2 });
    const css = `body{margin:0;background:transparent} .ce-backdrop{display:none} .ce-stage > g{visibility:hidden} ${sel}, ${sel} *{visibility:visible} .ce-press,.ce-press *{visibility:hidden}`;
    await p.setContent(`<!doctype html><style>${css}</style><body><div style="width:1280px">${svg}</div></body>`);
    await p.waitForTimeout(100);
    const png = await p.screenshot({ omitBackground: true });
    const pts = await p.evaluate(async (b64) => {
      const img = new Image(); img.src = 'data:image/png;base64,' + b64; await img.decode();
      const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const g = c.getContext('2d'); g.drawImage(img, 0, 0);
      const W = c.width, H = c.height, a = g.getImageData(0, 0, W, H).data; const A = (x, y) => (x < 0 || y < 0 || x >= W || y >= H) ? 0 : a[(y * W + x) * 4 + 3];
      const res = []; let n = 0;
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        if (A(x, y) > 127 && (A(x - 1, y) <= 127 || A(x + 1, y) <= 127 || A(x, y - 1) <= 127 || A(x, y + 1) <= 127)) { if ((n++) % 2 === 0) res.push([(x + 0.5) / 8, (y + 0.5) / 8]); }
      }
      return res;
    }, png.toString('base64'));
    out[name] = pts.map((q) => q.map((v) => +v.toFixed(3))); await p.close();
    console.log(name, pts.length);
  }
  await b.close();
  fs.writeFileSync(__dirname + '/contours.json', JSON.stringify(out));
})();
