// cubic-bezier easing helpers (same math as CSS)
function bez(x1, y1, x2, y2) {
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  const X = (s) => ((ax * s + bx) * s + cx) * s, Y = (s) => ((ay * s + by) * s + cy) * s;
  const dX = (s) => (3 * ax * s + 2 * bx) * s + cx;
  return (t) => {
    if (t <= 0) return 0; if (t >= 1) return 1;
    let s = t; for (let i = 0; i < 8; i++) { const e = X(s) - t; const d = dX(s); if (Math.abs(e) < 1e-7) break; if (Math.abs(d) < 1e-6) break; s -= e / d; }
    let lo = 0, hi = 1; if (Math.abs(X(s) - t) > 1e-6) { s = t; for (let i = 0; i < 40; i++) { if (X(s) < t) lo = s; else hi = s; s = (lo + hi) / 2; } }
    return Y(s);
  };
}
module.exports = { bez };
if (require.main === module) {
  const [x1, y1, x2, y2] = process.argv.slice(2).map(Number); const f = bez(x1, y1, x2, y2);
  let tHalf = 0, vmax = 0, tv = 0; const N = 2000;
  for (let i = 1; i <= N; i++) { const t = i / N, v = (f(t) - f(t - 1 / N)) * N; if (v > vmax) { vmax = v; tv = t; } if (!tHalf && f(t) >= 0.5) tHalf = t; }
  console.log({ tHalf: +tHalf.toFixed(3), peakVel: +vmax.toFixed(3), tPeak: +tv.toFixed(3), p10: +f(.1).toFixed(3), p25: +f(.25).toFixed(3), p75: +f(.75).toFixed(3), p90: +f(.9).toFixed(3) });
}
