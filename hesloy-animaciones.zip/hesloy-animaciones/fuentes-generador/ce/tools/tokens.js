'use strict';
// contra-entrega design tokens: [day, night]. gen-motion.js writes them into ce.css as the day block (.hsa-ce),
// the night block ([data-hsa-theme="noche"]) and the identical prefers-color-scheme copy for "auto", so the three
// can never drift apart. The day values are also the SVG fallbacks used by build-cash.js.
module.exports = {
  // shadows (one offset direction, down-right) and light
  'shadow': ['#5A3A1E', '#000000'], 'sh-c': ['.16', '.5'], 'sh-a': ['.3', '.4'], 'sh-b': ['.03', '.015'],
  'rim': ['#D9BC77', '#D9BC77'], 'rim-op': ['0', '.6'],
  // silhouette hairline: day = opaque pre-mixed warm tones; night = off (value separation + gold rim)
  'hair-op': ['1', '0'],
  'paper-lip': ['#FFFFFF', '#D3DCC6'],
  // hand a (giver, light skin): dorsal / palmar / lines / nail
  'a-hi': ['#F2CBA7', '#E2B48E'], 'a-mid': ['#E0A982', '#C08D66'], 'a-lo': ['#BC8259', '#A9744E'],
  'a-palm-hi': ['#F4CDAB', '#E4B792'], 'a-palm-mid': ['#E3AC86', '#C3906A'], 'a-palm-lo': ['#C0865E', '#AC7851'],
  'a-line': ['#9A6440', '#7A4C30'], 'a-hair': ['#CC9C78', '#A9744E'], 'a-edge': ['#B57C55', '#8A5838'],
  'a-crease': ['#A86C49', '#8A5838'], 'a-nail': ['#EFCDB8', '#DDB59B'], 'a-nail-hi': ['#F8E4D6', '#EBCDB8'],
  // hand b (receiver, deeper skin): the palm is lighter and warmer than the dorsum
  'b-hi': ['#D3A077', '#BE8D66'], 'b-mid': ['#B9845B', '#A3734F'], 'b-lo': ['#8E5E3C', '#7C5134'],
  'b-palm-hi': ['#DDB08A', '#C89D79'], 'b-palm-mid': ['#C9976E', '#B38662'], 'b-palm-lo': ['#A06E4A', '#8E6142'],
  'b-line': ['#6A4128', '#4E2F1B'], 'b-hair': ['#A57552', '#7C5134'], 'b-edge': ['#875838', '#5E3B24'],
  'b-crease': ['#7E5133', '#63402A'], 'b-nail': ['#D7AA8A', '#C29880'], 'b-nail-hi': ['#E9C9B0', '#D5B29A'],
  // giver sleeve: cafe blazer + ivory shirt cuff (night: lifted on the elevation ladder, gold rim + stitch)
  'blazer-hi': ['#866534', '#7A5E38'], 'blazer-mid': ['#6B4E23', '#5E472A'], 'blazer-lo': ['#57401F', '#4A3720'],
  'blazer-in': ['#3D2B15', '#1E160D'], 'stitch': ['#A88B5C', '#D9BC77'],
  'cuff-hi': ['#FFFDF8', '#EDE7DA'], 'cuff-mid': ['#F3ECDF', '#DCD3C2'], 'cuff-lo': ['#DCD1BC', '#BDB29C'], 'cuff-line': ['#CFC4AE', '#A99F8A'],
  'gold': ['#B8924A', '#D9BC77'], 'gold-hi': ['#F1DDA6', '#F1DFB2'],
  // receiver sleeve: knit (night lowered so it does not glow; gold rim keeps it off the ground)
  'knit-hi': ['#E9DAB9', '#B2A07C'], 'knit-mid': ['#D9C6A0', '#918060'], 'knit-lo': ['#B09A6E', '#6A5B41'],
  'rib-dk': ['#A89470', '#56492F'], 'rib-lt': ['#FFF9EC', '#CDBE9A'],
  // bill: warm sage, matte; night keeps the hue (~90 deg) and only lowers the value
  'bill-hi': ['#E3EBD8', '#BCC8AC'], 'bill-mid': ['#DAE5D0', '#B0BEA0'], 'bill-lo': ['#CFDDC6', '#9FAF90'],
  'bill-light': ['#EEF3E6', '#C6D0B8'], 'bill-ink': ['#3E6347', '#2E4A32'], 'bill-guil': ['#9DB79A', '#84987A'],
  'bill-edge': ['#5E8A69', '#74896A'], 'bill-lip': ['#FFFFFF', '#D3DCC6'],
};
