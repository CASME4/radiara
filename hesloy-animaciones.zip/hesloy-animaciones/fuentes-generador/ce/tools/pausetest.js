// pausing during the stage breath must show a complete opaque pose
const { chromium } = require('/opt/node-tools/node_modules/playwright'); const fs = require('fs');
(async () => {
  const D = __dirname + '/..'; const svg = fs.readFileSync(D + '/out/contra-entrega.svg', 'utf8'), css = fs.readFileSync(D + '/out/assembled.css', 'utf8');
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 960, height: 540 } });
  await p.setContent(`<!doctype html><style>${css}</style><body data-hsa-theme="dia"><div style="width:960px">${svg}</div></body>`);
  for (const t of [5500, 5700, 5760, 5900]) {
    const r = await p.evaluate((t) => { document.getAnimations().forEach((a) => { a.pause(); a.currentTime = t; }); const st = document.querySelector('.ce-stage'); const before = +getComputedStyle(st).opacity; document.querySelector('svg.hsa-ce').classList.add('hsa-paused'); const after = +getComputedStyle(st).opacity; document.querySelector('svg.hsa-ce').classList.remove('hsa-paused'); const again = +getComputedStyle(st).opacity; return { before, after, again }; }, t);
    console.log(t, JSON.stringify(r));
  }
  await b.close();
})();
