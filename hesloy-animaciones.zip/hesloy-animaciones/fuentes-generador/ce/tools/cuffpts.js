// exports the exact cuff polygons (final viewBox coords, contact pose) from build-cash.js internals -> tools/cuffs.json
const fs = require('fs'), path = require('path'), Module = require('module');
const DIR = path.resolve(__dirname, '..');
const src = fs.readFileSync(DIR + '/build-cash.js', 'utf8') + '\nmodule.exports.__x = { hand, PA, PB, toFinal };\n';
const m = new Module(DIR + '/build-cash.js', null); m.filename = DIR + '/build-cash.js'; m.paths = Module._nodeModulePaths(DIR);
m._compile(src, DIR + '/build-cash.js');
const { hand, PA, PB, toFinal } = m.exports.__x;
const A = hand('a', PA, 'blazer'), B = hand('b', PB, 'knit');
const r = (p) => p.map((n) => +n.toFixed(3));
const out = { giverCuffVisible: A.cuffVisible.map((p) => r(toFinal(PA, p))), receiverCuff: B.cuff.map((p) => r(toFinal(PB, p))) };
fs.writeFileSync(__dirname + '/cuffs.json', JSON.stringify(out));
console.log('giver min x', Math.min(...out.giverCuffVisible.map((p) => p[0])), 'receiver max x', Math.max(...out.receiverCuff.map((p) => p[0])));
