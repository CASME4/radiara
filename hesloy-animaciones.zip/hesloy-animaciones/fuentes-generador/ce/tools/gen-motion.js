'use strict';
// Generates variants/ce/ce.css: header + design tokens (day / night / auto, from tools/tokens.js) + MOTION.
// node tools/gen-motion.js   -> rewrites ../ce.css and writes tools/motion.json (phases for check-lock.js)
const fs = require('fs'), path = require('path');
const DIR = path.resolve(__dirname, '..');
const BC = require(DIR + '/build-cash.js'); const PIV = BC.PIVOTS;
const TOK = require('./tokens.js');

// ---------------------------------------------------------------- parameters
const P = {
  dur: 5.4,
  dg: 31,        // giver start/end offset along -axis (u): opens the free-hand gaps to >= 5 u
  dr: 28,        // receiver start/end offset along -axis (u); 28 keeps the rib cuff >= 2 u off the edge fade
  tug: 3.2,      // receiver + bill pull toward the receiver (u, ~3 px at 300 px)
  yield: 0.25,   // the giver is dragged this fraction of the tug, then recoils as it lets go
  hG: 2.2,       // giver reach arc (perpendicular hump, u, upward; scaled with dg 28 -> 31)
  hGx: -1.55,    // giver withdrawal arc (u, negative = downward: the emptied hand relaxes and drops)
  hR: 1.6,       // receiver reach arc (u, upward)
  hT: 1.4,       // receiver take arc (u, upward)
  rotG: 2.6,     // giver rest tilt (deg, clockwise = fingertips relaxed down)
  rotR: -2.8,    // receiver rest tilt (deg, counter-clockwise = fingertips relaxed down)
  thG: 6,        // giver thumb abduction when empty (deg, canonical +deg = opens; tip moves ~7 u)
  thR: 8,        // receiver thumb abduction while it waits (deg; ~9.5 u at the tip: reads as "open, ready")
};
// key times, authored in MILLISECONDS (converted to % of the loop below; 1 % = 54 ms)
const MS = {
  g0: 308, g1: 1176,           // giver reach (translate): offer, 868 ms
  gr0: 362, gr1: 1260,         // giver de-tilt (rotation lags the translate: follow-through)
  r0: 476, r1: 1372,           // receiver reach, 896 ms: responds 168 ms later, lands 196 ms after the giver
  rr0: 502, rr1: 1400,         // receiver de-tilt
  rth0: 840, rth1: 1372,       // receiver thumb closes onto the paper as the hand lands
  rp0: 1345, rp1: 1426,        // receiver paper dent + pulp contact shadow appear as the thumb lands
  swap: 1782,                  // bill B -> bill A (identical CTM: both ride the giver; nothing moves)
  pivot: 1890,                 // bill A pivot switch giver -> receiver wrist (both rotations are 0 here)
  t0: 2268, t1: 2436,          // contact hold 842 ms, then the tug (receiver + bill, 168 ms); the giver yields a little
  gy1: 2518,                   // giver recoil back to 0 after the yield
  gp0: 2436, gp1: 2516,        // giver lets go: its paper dent + pulp contact shadow fade (thumb lifts)
  gth0: 2436, gth1: 2716,      // giver thumb opens (empty hand stops "pinching air")
  gx0: 2490, gx1: 3582,        // giver withdraws, 1092 ms (leads the take by 26 ms, right after its recoil)
  grx0: 2570, grx1: 3690,      // giver wrist relaxes back to its rest tilt
  rx0: 2516, rx1: 3664,        // receiver takes the bill home, 1148 ms
  rrx0: 2598, rrx1: 3758,      // receiver wrist relaxes back to its rest tilt
  // loop dissolve (only the bill and the two thumbs change; hands and halo never change opacity)
  ro0: 4510, ro1: 4806,        // receiver thumb opens: the hand lets go of the dissolving bill
  rpo0: 4536, rpo1: 4644,      // receiver dent fades as its thumb lifts
  ao0: 4536, ao1: 4730,        // bill A fades out in the receiver's hand (194 ms, ease-in: holds, then goes)
  jump: 4752,                  // bill A (invisible) returns to the giver's channels and pivot
  bi0: 4780, bi1: 4970,        // bill B fades in at the giver's open grip (190 ms, ease-out). Sequential, 50 ms
                               // apart: never two translucent bills over each other (they would overlap by
                               // ~28 u in the middle); the bill is below 30 % for ~110 ms, while both thumbs move
  gc0: 4752, gc1: 5022,        // giver thumb closes onto bill B
  gpi0: 4940, gpi1: 5022,      // giver dent + pulp contact shadow appear as its thumb lands
};
for (const [k, t] of Object.entries(MS)) P[k] = +(t / (P.dur * 10)).toFixed(2);
const J = P.jump, Jb = +(P.jump + 0.01).toFixed(2), SWb = +(P.swap + 0.01).toFixed(2), PVb = P.pivot;
// easings
const E = {
  reachG: 'cubic-bezier(.45, 0, .36, 1)',   // precise reach (velocity peak 40 %, long precise landing)
  reachR: 'cubic-bezier(.45, 0, .3, 1)',    // decided response, firm landing (no creep)
  tilt: 'cubic-bezier(.4, 0, .3, 1)',
  tug: 'cubic-bezier(.35, 0, .15, 1)',
  recoil: 'cubic-bezier(.3, 0, .3, 1)',
  departG: 'cubic-bezier(.3, 0, .3, 1)',    // the emptied hand leaves promptly, soft start
  take: 'cubic-bezier(.33, 0, .28, 1)',
  relax: 'cubic-bezier(.45, 0, .45, 1)',
  thumbOpen: 'cubic-bezier(.3, 0, .2, 1)',
  thumbClose: 'cubic-bezier(.4, 0, .2, 1)',
  dent: 'cubic-bezier(.3, 0, .3, 1)',
  fadeOut: 'cubic-bezier(.4, 0, 1, 1)',    // bill A leaves: ease-in (ends at 0, invisible)
  fadeIn: 'cubic-bezier(0, 0, .4, 1)',      // bill B arrives: ease-out (starts at 0, invisible)
};
// hump halves fitted to h*sin(pi*e(t)) for each main easing (tools/fithump.js)
const HUMP = {
  reachG: { tHalf: 0.429, up: 'cubic-bezier(.58, 0, .72, .99)', down: 'cubic-bezier(.22, .02, .38, 1)' },
  reachR: { tHalf: 0.406, up: 'cubic-bezier(.61, 0, .72, .99)', down: 'cubic-bezier(.2, .02, .35, 1)' },
  departG: { tHalf: 0.35, up: 'cubic-bezier(.48, 0, .64, 1)', down: 'cubic-bezier(.21, .01, .4, 1)' },
  take: { tHalf: 0.354, up: 'cubic-bezier(.52, 0, .66, 1)', down: 'cubic-bezier(.21, .02, .38, 1)' },
};

// ---------------------------------------------------------------- geometry
const r2 = (n) => { const v = Math.round(n * 100) / 100; return (Object.is(v, -0) ? 0 : v).toString().replace(/^(-?)0\./, '$1.'); };
const pct = (n) => `${r2(n)}%`.replace(/^\./, '0.');
const OG = PIV.giver.wrist, OR = PIV.receiver.wrist;
const AG = PIV.giver.axis, AR = PIV.receiver.axis;               // elbow -> fingertips
const perpUp = (a) => { const c = [a[1], -a[0]], d = [-a[1], a[0]]; return c[1] < d[1] ? c : d; };
const NG = perpUp(AG), NR = perpUp(AR);
const SG = [-AG[0] * P.dg, -AG[1] * P.dg];                       // retreat = -axis
const SR = [-AR[0] * P.dr, -AR[1] * P.dr];
const TUG = [-AR[0] * P.tug, -AR[1] * P.tug];
const YG = [TUG[0] * P.yield, TUG[1] * P.yield];
const HG = [NG[0] * P.hG, NG[1] * P.hG], HGx = [NG[0] * P.hGx, NG[1] * P.hGx], HR = [NR[0] * P.hR, NR[1] * P.hR], HT = [NR[0] * P.hT, NR[1] * P.hT];
const tr = (v) => `translate: ${r2(v[0])}px ${r2(v[1])}px;`;
const tz = 'translate: 0px 0px;';
const xf = (v) => `transform: translate(${r2(v[0])}px, ${r2(v[1])}px);`;
const xz = 'transform: translate(0px, 0px);';
const rt = (d) => `rotate: ${r2(d)}deg;`;
const op = (o) => `opacity: ${o};`;
const tf = (e) => ` animation-timing-function: ${e};`;
const org = (o) => `${r2(o[0])}px ${r2(o[1])}px`;

// keyframe list helper: [[pct or [pcts], decl, easing?], ...]
function kf(name, rows, comment) {
  let s = comment ? `/* ${comment} */\n` : '';
  s += `@keyframes ${name} {\n`;
  for (const [at, decl, e] of rows) {
    const sel = (Array.isArray(at) ? at : [at]).map(pct).join(', ');
    s += `  ${sel.padEnd(14)} { ${decl}${e ? tf(e) : ''} }\n`;
  }
  return s + '}\n';
}
const humpRows = (h, a, b, H) => {
  const tp = a + HUMP[h].tHalf * (b - a);
  return [[a, xz, HUMP[h].up], [tp, xf(H), HUMP[h].down], [b, xz]];
};

// ---- giver channels (bill B always rides them; bill A copies them while the giver holds it)
const gT = [[[0, P.g0], tr(SG), E.reachG], [[P.g1, P.t0], tz, E.tug], [P.t1, tr(YG), E.recoil], [P.gy1, tz, E.departG], [[P.gx1, 100], tr(SG)]];
const gR = [[[0, P.gr0], rt(P.rotG), E.tilt], [[P.gr1, P.grx0], rt(0), E.relax], [[P.grx1, 100], rt(P.rotG)]];
const gH = [[0, xz], ...humpRows('reachG', P.g0, P.g1, HG), ...humpRows('departG', P.gx0, P.gx1, HGx), [100, xz]];
// ---- receiver channels
const rT = [[[0, P.r0], tr(SR), E.reachR], [[P.r1, P.t0], tz, E.tug], [[P.t1, P.rx0], tr(TUG), E.take], [[P.rx1, 100], tr(SR)]];
const rR = [[[0, P.rr0], rt(P.rotR), E.tilt], [[P.rr1, P.rrx0], rt(0), E.relax], [[P.rrx1, 100], rt(P.rotR)]];
const rH = [[0, xz], ...humpRows('reachR', P.r0, P.r1, HR), ...humpRows('take', P.rx0, P.rx1, HT), [100, xz]];
// ---- bill A = giver until the tug starts (translate) / until the pivot switch (rotate), receiver afterwards;
//      once it has dissolved (opacity 0) it jumps back onto the giver's channels, so 100 % == 0 %
const aT = [[[0, P.g0], tr(SG), E.reachG], [[P.g1, P.t0], tz, E.tug], [[P.t1, P.rx0], tr(TUG), E.take], [[P.rx1, J], tr(SR), 'step-end'], [[Jb, 100], tr(SG)]];
const aR = [[[0, P.gr0], rt(P.rotG), E.tilt], [[P.gr1, P.rrx0], rt(0), E.relax], [[P.rrx1, J], rt(P.rotR), 'step-end'], [[Jb, 100], rt(P.rotG)]];
const aH = [[0, xz], ...humpRows('reachG', P.g0, P.g1, HG), ...humpRows('take', P.rx0, P.rx1, HT), [100, xz]];
const aO = [[0, `transform-origin: ${org(OG)};`, 'step-end'], [PVb, `transform-origin: ${org(OR)};`, 'step-end'], [[Jb, 100], `transform-origin: ${org(OG)};`]];
// ---- bill opacities: B (giver's copy) is the visible bill from the wrap until the swap and again from its fade-in;
//      A is the visible bill from the swap until it dissolves in the receiver's hand. Never both, never none at the
//      swap (same keyframe boundary, same CTM).
const aOp = [[[0, P.swap], op(0), 'step-end'], [[SWb, P.ao0], op(1), E.fadeOut], [[P.ao1, 100], op(0)]];
const bOp = [[[0, P.swap], op(1), 'step-end'], [[SWb, P.bi0], op(0), E.fadeIn], [[P.bi1, 100], op(1)]];
// ---- thumbs (rigid layer about the base of the thenar; canonical +deg opens both thumbs)
const gTh = [[[0, P.gth0], rt(0), E.thumbOpen], [[P.gth1, P.gc0], rt(P.thG), E.thumbClose], [[P.gc1, 100], rt(0)]];
const rTh = [[[0, P.rth0], rt(P.thR), E.thumbClose], [[P.rth1, P.ro0], rt(0), E.thumbOpen], [[P.ro1, 100], rt(P.thR)]];
// ---- paper dents (+ pulp contact shadows)
const gpOp = [[[0, P.gp0], op(1), E.dent], [[P.gp1, P.gpi0], op(0), E.dent], [[P.gpi1, 100], op(1)]];
const rpOp = [[[0, P.rp0], op(0), E.dent], [[P.rp1, P.rpo0], op(1), E.dent], [[P.rpo1, 100], op(0)]];

// ---------------------------------------------------------------- tokens
// build-cash.js fallbacks (TONES) must equal the day tokens
for (const id of ['a', 'b']) for (const [k, val] of Object.entries(BC.TONES[id])) {
  const name = BC.tokName(id, k).replace(/^ce-/, '');
  if (!TOK[name]) throw new Error(`token --ce-${name} missing in tools/tokens.js`);
  if (TOK[name][0].toUpperCase() !== val.toUpperCase()) throw new Error(`--ce-${name}: tokens.js ${TOK[name][0]} vs build-cash ${val}`);
}
const block = (sel, i, ind = '') => `${sel} {\n${Object.entries(TOK).map(([k, v]) => `${ind}  --ce-${k}: ${v[i]};`).join('\n')}\n${ind}}\n`;

const A = (n) => `${n} var(--hsa-ce-dur) linear infinite both`;
const ms = (a) => Math.round(a * P.dur * 10);
let css = `/* @module contra-entrega:start */
/* ==========================================================================
   1 · CONTRA ENTREGA  (loop ${P.dur} s) · generado por variants/ce/tools/gen-motion.js
   Pose del marcado = contacto con el billete sujeto por ambas manos.
   Cada mano está dividida en dos capas (--back detrás del billete,
   --front delante: pulgar y manga) que comparten la MISMA animación,
   así que se trasladan como una sola pieza rígida. Dentro de --front,
   .ce-thumb (pulgar + tenar) es una capa rígida que gira sobre la base
   de la tenar (bajo el puño) y .ce-press es el hundimiento del papel.
   Dos manos distintas (handgeo.js / handgeo-b.js), piel tokenizada por
   mano (--ce-a-* entrega, --ce-b-* recibe; *-palm-* = piel palmar).
   ========================================================================== */
/* Tokens · día */
${block('.hsa-ce', 0)}/* Tokens · noche: superficies elevadas, borde dorado en los contornos iluminados; mismos tonos, menos valor */
${block('[data-hsa-theme="noche"] .hsa-ce,\n.hsa-ce[data-hsa-theme="noche"]', 1)}@media (prefers-color-scheme: dark) {
${block('  [data-hsa-theme="auto"] .hsa-ce', 1, '  ')}}
`;
css += `.hsa-ce { --hsa-ce-dur: ${P.dur}s; }
/* ---------- Movimiento ------------------------------------------------------
   Lazo de ${P.dur} s (1 % = ${ms(1)} ms).
   0-${P.g0} % reposo completo: quien entrega sostiene el billete, quien recibe espera con el pulgar abierto.
   ${P.g0}-${P.g1} % quien entrega ofrece (${ms(P.g1 - P.g0)} ms, arco de ${P.hG} u; la muñeca se endereza ${ms(P.gr1 - P.g1)} ms después).
   ${P.r0}-${P.r1} % quien recibe responde ${ms(P.r0 - P.g0)} ms más tarde y llega ${ms(P.r1 - P.g1)} ms después; su pulgar se
   cierra sobre el papel (${P.rth0}-${P.rth1} %). ${P.rp1}-${P.t0} % contacto inmóvil (${ms(P.t0 - P.rp1)} ms).
   ${P.t0}-${P.t1} % tirón de ${P.tug} u: quien entrega cede ${r2(P.tug * P.yield)} u y el billete se desliza bajo su pulgar.
   ${P.gp0} % suelta (desaparece el hundimiento del papel); ${P.gth0}-${P.gth1} % su pulgar se abre;
   ${P.gx0}-${P.gx1} % se retira ${P.dg} u con un arco hacia abajo; ${P.rx0}-${P.rx1} % quien recibe se lleva el billete ${P.dr} u.
   ${P.rrx1}-${P.ro0} % reposo final. Disolución del lazo: solo cambian el billete y los pulgares (las manos,
   las mangas y el halo nunca cambian de opacidad; el billete solo falta ~110 ms): ${P.ao0}-${P.ao1} % el billete A se
   desvanece en la mano de quien recibe mientras su pulgar se abre (${P.ro0}-${P.ro1} %); ${P.bi0}-${P.bi1} % el billete B
   (<use> del mismo dibujo, en la misma capa) aparece en la pinza abierta de quien entrega y su pulgar se
   cierra sobre él (${P.gc0}-${P.gc1} %). B viaja siempre con quien entrega: es el billete visible desde el cierre
   del lazo hasta ${P.swap} %, cuando pasa a A en pleno contacto inmóvil (mismo CTM, mismo fotograma: invisible).
   Todas las capas tienen el mismo estado calculado en 0 % y en 100 %.
   Canales independientes por capa rígida (sin escalar ni deformar): translate (recorrido),
   rotate (muñeca, transform-origin en el pivote) y transform (arco perpendicular).
   El billete copia exactamente los canales de la mano que lo sostiene; su pivote cambia
   de muñeca en ${P.pivot} %, con ambos giros a 0. Pose del marcado = contacto (movimiento reducido).
   --------------------------------------------------------------------------- */
.hsa-ce .ce-giver    { transform-box: view-box; transform-origin: ${org(OG)}; }
.hsa-ce .ce-receiver { transform-box: view-box; transform-origin: ${org(OR)}; }
.hsa-ce .ce-bill     { transform-box: view-box; transform-origin: ${org(OG)}; }
.hsa-ce .ce-bill-b   { transform-box: view-box; transform-origin: ${org(OG)}; }
/* .ce-thumb vive dentro de la colocación de la mano: su origen va en unidades canónicas de la mano */
.hsa-ce .ce-giver--front .ce-thumb    { transform-box: view-box; transform-origin: ${org(PIV.giver.thumbPivotLocal)}; }
.hsa-ce .ce-receiver--front .ce-thumb { transform-box: view-box; transform-origin: ${org(PIV.receiver.thumbPivotLocal)}; }
.hsa-ce .ce-giver    { animation: ${A('ce-g-t')}, ${A('ce-g-r')}, ${A('ce-g-h')}; }
.hsa-ce .ce-receiver { animation: ${A('ce-r-t')}, ${A('ce-r-r')}, ${A('ce-r-h')}; }
.hsa-ce .ce-bill     { animation: ${A('ce-a-t')}, ${A('ce-a-r')}, ${A('ce-a-h')}, ${A('ce-a-pivot')}, ${A('ce-a-op')}; }
.hsa-ce .ce-bill-b   { animation: ${A('ce-g-t')}, ${A('ce-g-r')}, ${A('ce-g-h')}, ${A('ce-b-op')}; }
.hsa-ce .ce-giver--front .ce-thumb    { animation: ${A('ce-gt-r')}; }
.hsa-ce .ce-receiver--front .ce-thumb { animation: ${A('ce-rt-r')}; }
.hsa-ce .ce-giver--front .ce-press    { animation: ${A('ce-gp-op')}; }
.hsa-ce .ce-receiver--front .ce-press { animation: ${A('ce-rp-op')}; }
/* En pausa (manual o fuera de pantalla) o al imprimir nunca se congelan dos billetes a medio disolver: se
   muestra A, que en cualquier instante está en una pinza (la de quien entrega fuera de su tramo propio).
   !important gana a la animación sin reiniciarla, así que al reanudar sigue en fase con el resto. */
.hsa-ce.hsa-paused .ce-bill { opacity: 1 !important; }
.hsa-ce.hsa-paused .ce-bill-b { opacity: 0 !important; }
@media print {
  .hsa-ce .ce-bill { opacity: 1 !important; }
  .hsa-ce .ce-bill-b { opacity: 0 !important; }
}

`;
css += kf('ce-g-t', gT, 'Quien entrega · recorrido a lo largo del antebrazo; cede en el tirón y retrocede al soltar (también lo usa el billete B)');
css += kf('ce-g-r', gR, 'Quien entrega · muñeca inclinada en reposo, recta durante la entrega');
css += kf('ce-g-h', gH, 'Quien entrega · arco perpendicular: sube al ofrecer, cae al retirarse vacía');
css += kf('ce-r-t', rT, 'Quien recibe · llegada, tirón y retirada con el billete');
css += kf('ce-r-r', rR, 'Quien recibe · llega inclinada y se endereza; al llevarse el billete vuelve a relajarse');
css += kf('ce-r-h', rH, 'Quien recibe · arcos de llegada y de retirada');
css += kf('ce-a-t', aT, 'Billete A · = ce-g-t hasta el tirón, = ce-r-t desde el tirón; ya invisible, vuelve a ce-g-t');
css += kf('ce-a-r', aR, 'Billete A · = ce-g-r hasta el cambio de pivote, = ce-r-r después');
css += kf('ce-a-h', aH, 'Billete A · arco de llegada (lo sostiene quien entrega) y de retirada (quien recibe)');
css += kf('ce-a-pivot', aO, `Billete A · pivote: muñeca de quien entrega hasta ${P.pivot} %, de quien recibe hasta volver (invisible)`);
css += kf('ce-a-op', aOp, `Billete A · visible desde el relevo (${P.swap} %, mismo CTM que B) hasta que se desvanece en la mano de quien recibe`);
css += kf('ce-b-op', bOp, 'Billete B · visible en la pinza de quien entrega: desde que aparece hasta el relevo del lazo siguiente');
css += kf('ce-gt-r', gTh, 'Pulgar de quien entrega · se abre al soltar; se cierra sobre el billete B');
css += kf('ce-rt-r', rTh, 'Pulgar de quien recibe · abierto mientras espera, se cierra sobre el papel al llegar, se abre al disolverse A');
css += kf('ce-gp-op', gpOp, 'Hundimiento del papel y sombra de contacto bajo el pulgar de quien entrega');
css += kf('ce-rp-op', rpOp, 'Hundimiento del papel y sombra de contacto bajo el pulgar de quien recibe');

fs.writeFileSync(DIR + '/ce.css', css + '/* @module contra-entrega:end */\n');
fs.writeFileSync(__dirname + '/motion.json', JSON.stringify({ P, OG, OR, SG, SR, TUG, YG, HG, HGx, HR, HT, dur: P.dur * 1000 }, null, 1));
console.log('ce.css written', { SG: SG.map(r2), SR: SR.map(r2), TUG: TUG.map(r2), YG: YG.map(r2), HG: HG.map(r2), HGx: HGx.map(r2), HR: HR.map(r2), HT: HT.map(r2) });
