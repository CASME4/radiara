// node extent.js <svg> <selectorToKeep> <out.png>  -> renders only that group (transparent bg) at 4 px/u
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
(async () => {
  const [,, svgf, keep, out] = process.argv;
  const svg = fs.readFileSync(svgf, 'utf8');
  const css = `body{margin:0;background:transparent} .ce-backdrop{display:none} .ce-stage > g{visibility:hidden} .ce-stage ${keep}, .ce-stage ${keep} *{visibility:visible}`;
  fs.writeFileSync(out + '.html', `<!doctype html><style>${css}</style><body><div style="width:1280px">${svg.replace('mask="url(#ce-fade)"','')}</div></body>`);
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1280, height: 720 } });
  await p.goto('file://' + out + '.html'); await p.waitForTimeout(150);
  await p.screenshot({ path: out, omitBackground: true }); await b.close(); fs.unlinkSync(out + '.html');
})();
