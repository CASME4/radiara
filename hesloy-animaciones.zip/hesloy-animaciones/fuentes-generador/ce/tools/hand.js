// node tools/hand.js <svg> <giver|receiver> <out.png> [thumbDeg=0] [dia|noche] [pxPerUnit=8]
// Renders ONE hand (back + front layers, no bill, no other hand) on the scene background, cropped to the hand,
// with its rigid thumb layer rotated by thumbDeg (canonical +deg = opens). Used for x4+ anatomy inspection.
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'), path = require('path');
const DIR = path.resolve(__dirname, '..');
const PIV = require(DIR + '/build-cash.js').PIVOTS;
(async () => {
  const [,, svgf, who, out, th = '0', theme = 'dia', ppu = '8'] = process.argv;
  const svg = fs.readFileSync(svgf, 'utf8').replace('mask="url(#ce-fade)"', '');
  const pv = PIV[who].thumbPivotLocal; const bg = theme === 'noche' ? '#0C0A09' : '#F4F1EA';
  const assembled = fs.existsSync(DIR + '/out/assembled.css') ? fs.readFileSync(DIR + '/out/assembled.css', 'utf8') : '';
  const W = 320 * +ppu;
  const css = `${assembled} *{animation:none!important} body{margin:0;background:${bg}} .ce-stage > g{visibility:hidden} .ce-${who}, .ce-${who} *{visibility:visible}
    .ce-${who}--front .ce-thumb{transform-box:view-box;transform-origin:${pv[0]}px ${pv[1]}px;rotate:${th}deg}`;
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: W, height: W * 180 / 320 } });
  await p.setContent(`<!doctype html><style>${css}</style><body data-hsa-theme="${theme}"><div style="width:${W}px">${svg}</div></body>`);
  await p.waitForTimeout(120);
  const box = await p.evaluate((who) => {
    const els = [...document.querySelectorAll(`.ce-${who}`)]; let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (const e of els) { const r = e.getBoundingClientRect(); x0 = Math.min(x0, r.left); y0 = Math.min(y0, r.top); x1 = Math.max(x1, r.right); y1 = Math.max(y1, r.bottom); }
    return { x: Math.max(0, x0 - 10), y: Math.max(0, y0 - 10), width: Math.min(innerWidth, x1 + 10) - Math.max(0, x0 - 10), height: Math.min(innerHeight, y1 + 10) - Math.max(0, y0 - 10) };
  }, who);
  await p.screenshot({ path: out, clip: box }); await b.close();
})();
