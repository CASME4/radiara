/* Transferencia · generator (SVG + sampled keyframes) — round 3
   ---------------------------------------------------------------------------------------------
   CSS contract with the render kit (kit/render-scene.sh):
   css() returns { coin, lit }. The kit rewrites tr.css between the markers
   "@keyframes tr-coin {" and "@keyframes tr-pulse-origen", writing
       @keyframes tr-coin { <coin> }  @keyframes tr-lit { <lit> }
   <lit> deliberately carries extra generated keyframes after its own body
   ("...}\n@keyframes tr-trail-1 {..." etc.), so EVERY timeline-dependent keyframe set is
   regenerated from the constants below: tr-coin (transform/opacity), tr-lit (comet + mask dash
   offset), tr-trail-1..N (per-layer comet opacity; the route mask reuses the last, longest-lived
   one), tr-coin-sh (ambient shadow) and tr-coin-cs (contact shadow). Never hand-edit those
   percentages in tr.css. "@keyframes tr-pulse-origen {}" in tr.css is an intentionally EMPTY
   rule kept only as the kit's end marker. Running `node build-transfer.js` prints the block.

   Scene: the coin rests on the origin pediment medallion (covering it completely: both
   medallions stay at opacity 1 all loop, revealed/covered only by occlusion), presses 2.4 u into
   it, launches along one arc (apex y = 22, landing tangent ≈ 28°) with a reach profile on arc
   length (velocity ∝ u^1.5 (1-u)^2, peak at 43% of the flight) and a speed-proportional lean
   (≤ 4°), overshoots the destination drum medallion by 1.6 u and settles (min-jerk), holds,
   then sinks into the medallion: scale 1 → .9 (the coin's inner ring and Q are drawn so that at
   .9 they land exactly on the medallion's ring and Q) while fading (ease-in, 260 ms); it
   re-emerges from the origin medallion as the time mirror of that dissolve.
   Comet trail = N stacked round-capped dashes on a sub-path that starts just above the pediment
   roof (never over the building). The route dots under the comet are removed by a luminance
   MASK on the route only (#tr-route-mask), so nothing is painted in the backdrop colour and the
   scene works on any host surface.
   Static markup (= prefers-reduced-motion pose): coin at mid-arc, short comet behind it,
   dotted route ahead, no glows.
   --------------------------------------------------------------------------------------------- */
const G = require('./geom'); G.setSimplify(0.03);
const { f1, fillv, strokev, stop, qGlyph } = require('./common');

const K = 1.1, GY = 152;                       // building scale, ground line
const W = (w) => f1(w / K);                    // world stroke width -> local (inside scaled bank groups)
const wy = (ly) => GY - (136 - ly) * K;        // local y -> world y
const wxA = (lx) => 76 + (lx - 64) * K, wxB = (lx) => 244 + (lx - 256) * K;
const MED_LY = 68.2, MY = wy(MED_LY);          // medallion centre (both banks, same height)
const MED_R = 4.6;                             // medallion disc radius (local)
const TA = [76 - 64 * K, GY - 136 * K], TB = [244 - 256 * K, GY - 136 * K];
const S = [76, MY], E = [244, MY];
const AP = [156, 22];                          // apex (absolute; 9.2 u of sky above the halo)
const SEGS = [[S, [86, MY - 24], [112, AP[1]], AP], [AP, [180, AP[1]], [218, MY - 14], E]];
const COIN_R = 7.5, SINK = 0.9;                // coin radius; scale at the end of the dissolve
const cub = (P, t) => [0, 1].map((k) => (1 - t) ** 3 * P[0][k] + 3 * (1 - t) ** 2 * t * P[1][k] + 3 * (1 - t) * t * t * P[2][k] + t ** 3 * P[3][k]);
const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
function splitRight(P, t) {      // de Casteljau: the part of cubic P after t
  const p01 = lerp(P[0], P[1], t), p12 = lerp(P[1], P[2], t), p23 = lerp(P[2], P[3], t);
  const a = lerp(p01, p12, t), b = lerp(p12, p23, t), m = lerp(a, b, t);
  return [m, b, p23, P[3]];
}
const pt = (p) => f1(p[0]) + ' ' + f1(p[1]);
const cubD = (P) => `C${pt(P[1])} ${pt(P[2])} ${pt(P[3])}`;
// arc-length table over both segments
const N = 800, tab = [];
for (let i = 0; i <= N; i++) { const g = i / N * 2, si = Math.min(1, Math.floor(g)), t = g - si; tab.push({ p: cub(SEGS[si], si === 1 && g === 2 ? 1 : t), g }); }
tab[0].s = 0; for (let i = 1; i <= N; i++) tab[i].s = tab[i - 1].s + Math.hypot(tab[i].p[0] - tab[i - 1].p[0], tab[i].p[1] - tab[i - 1].p[1]);
const LEN = tab[N].s;
const unit = (a) => { const l = Math.hypot(a[0], a[1]); return [a[0] / l, a[1] / l]; };
const D0 = unit([SEGS[0][1][0] - S[0], SEGS[0][1][1] - S[1]]);   // launch direction
const D1 = unit([E[0] - SEGS[1][2][0], E[1] - SEGS[1][2][1]]);   // landing direction
function at(frac) {              // point on route at arc-length fraction (extrapolated past the ends)
  if (frac <= 0) return [S[0] + D0[0] * frac * LEN, S[1] + D0[1] * frac * LEN];
  if (frac >= 1) return [E[0] + D1[0] * (frac - 1) * LEN, E[1] + D1[1] * (frac - 1) * LEN];
  const target = frac * LEN; let i = 1; while (i < N && tab[i].s < target) i++;
  const a = tab[i - 1], b = tab[i], k = (target - a.s) / ((b.s - a.s) || 1);
  return [a.p[0] + (b.p[0] - a.p[0]) * k, a.p[1] + (b.p[1] - a.p[1]) * k];
}
const subRoute = (a, b, n = 22) => G.crPath(Array.from({ length: n + 1 }, (_, i) => at(a + (b - a) * i / n)), false);

// ---- where the route meets the buildings (world units) ---------------------------------------
const ROOF = [[wxA(64), wy(57.6)], [wxA(64 + 38.2), wy(75.6)]];     // origin roof, right slope (stroke 1.1)
const aboveRoof = (p) => {       // perpendicular distance of p above the roof line (positive = in the sky)
  const [a, b] = ROOF, m = (b[1] - a[1]) / (b[0] - a[0]);
  return (a[1] + (p[0] - a[0]) * m - p[1]) / Math.hypot(1, m);
};
const DOME = { cx: 244, cy: wy(59.7), rx: 17 * K, ry: 15.5 * K };
const CAP = { x0: wxB(256 - 18.4), x1: wxB(256 + 18.4), y0: wy(59.5), y1: wy(61.5) };
function clearDest(p) {          // distance from p to the dome / drum-cap silhouette (0 inside)
  let d = Infinity;
  for (let k = 0; k <= 180; k++) { const th = Math.PI * k / 180; d = Math.min(d, Math.hypot(p[0] - (DOME.cx - DOME.rx * Math.cos(th)), p[1] - (DOME.cy - DOME.ry * Math.sin(th)))); }
  const qx = Math.max(CAP.x0, Math.min(p[0], CAP.x1)), qy = Math.max(CAP.y0, Math.min(p[1], CAP.y1));
  return Math.min(d, Math.hypot(p[0] - qx, p[1] - qy));
}
const fracWhere = (pred, a, b, step = 0.0005) => { for (let u = a; step > 0 ? u <= b : u >= b; u += step) if (pred(u)) return +u.toFixed(4); return b; };
// comet sub-path starts 2.6 u above the roof (half the widest layer + half the roof stroke + margin)
const TRAIL_U0 = fracWhere((u) => aboveRoof(at(u)) >= 2.6, 0, 0.3);
const S0 = TRAIL_U0 * LEN;       // arc length of the sub-path start
// dotted route: from 4.5 u above the roof to 4.5 u before the drum cap / dome
const ROUTE = [fracWhere((u) => aboveRoof(at(u)) >= 4.5, 0, 0.3), +(fracWhere((u) => clearDest(at(u)) < 4.5, 0.6, 1) - 0.002).toFixed(4)];
const trailD = (() => {
  let i = 1; while (tab[i].s < S0) i++;
  const t = tab[i].g;            // ≤ 1 (first segment) by construction
  const P = splitRight(SEGS[0], t);
  return `M${pt(P[0])}${cubD(P)}${cubD(SEGS[1])}`;
})();

// ---- timeline (ms) ------------------------------------------------------------------------
const T = 5600;
const TA0 = 420, TL = 600;                      // anticipation (press into the medallion), launch
const TF = 2250, TS = 2474;                     // end of flight (= overshoot apex), settled (min-jerk)
const TD0 = 3540, TD1 = TD0 + 260;              // sink + dissolve into the destination medallion
const TE0 = 3900, TE1 = TE0 + 260;              // re-emerge from the origin medallion (mirror)
const PRESS = 2.4, OVER_U = 1.6, LEAN = 4;      // u, u, deg
const OVER = OVER_U / LEN;
const D_0 = -PRESS / LEN;                       // progress at the bottom of the press
const P_STATIC = 0.494;                           // reduced-motion pose (mid-arc)
const C_OFF = 1.1;                              // comet dash phase (keeps the zero-length lead dash off the path)
const NL = 6;                                   // comet layers, longest/faintest first; same head (the coin)
const TRAIL = Array.from({ length: NL }, (_, i) => ({
  L: [0.25, 0.175, 0.12, 0.08, 0.05, 0.028][i],
  w: +(0.8 + (2.6 - 0.8) * i / (NL - 1)).toFixed(2),
  in: 0.30 - i * 0.03,                          // flight-u where the layer is fully in (short layers first)
  f: [0.36 + 0.30 * i / (NL - 1), 0.58 + 0.30 * i / (NL - 1)], // fade-out window
}));
const TRAIL_OP = 0.12;

// reach profile: velocity ∝ u^1.5 (1-u)^2.0 (peak at 43%), integrated + normalised
const REACH = (() => { const n = 2000, c = [0]; for (let i = 1; i <= n; i++) { const u = (i - .5) / n; c.push(c[i - 1] + u ** 1.5 * (1 - u) ** 2.0); } return (u) => { const x = Math.max(0, Math.min(1, u)) * n, i = Math.floor(x); return (c[Math.min(n, i)] + (x - i) * ((c[Math.min(n, i + 1)] - c[Math.min(n, i)]))) / c[n]; }; })();
const mj = (u) => { u = Math.max(0, Math.min(1, u)); return u * u * u * (10 - 15 * u + 6 * u * u); };
function progress(t) {           // arc-length fraction (slightly < 0 in the press, > 1 at the overshoot)
  t = ((t % T) + T) % T;
  if (t <= TA0) return 0;
  if (t <= TL) return D_0 * mj((t - TA0) / (TL - TA0));
  if (t <= TF) return D_0 + (1 + OVER - D_0) * REACH((t - TL) / (TF - TL));
  if (t <= TS) return 1 + OVER * (1 - mj((t - TF) / (TS - TF)));
  return 1;
}
const flightPos = (t) => at(progress(t));
const VMAX = (() => { let m = 0; for (let t = TL; t <= TF; t += 2) m = Math.max(m, progress(t + 1) - progress(t - 1)); return m; })();
const lean = (t) => LEAN * (progress(t + 1) - progress(t - 1)) / VMAX;   // forward lean ∝ signed speed
const firstT = (pred, t0, t1) => { for (let t = t0; t <= t1; t += 1) if (pred(t)) return t; return t1; };

function stoneGrad(id, cx) {
  return `<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${cx - 40}" y1="0" x2="${cx + 40}" y2="0">${stop(0, 'tr-stone-hi', '#FFFDF8')}${stop(0.5, 'tr-stone', '#EFE7D8')}${stop(1, 'tr-stone-lo', '#D9CCB4')}</linearGradient>`;
}
function rimGrad(id, cx) {
  return `<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${cx - 40}" y1="0" x2="${cx + 40}" y2="0"><stop offset="0" style="stop-color:var(--hsa-gold,#B8924A);stop-opacity:var(--tr-rim-op,0)"/><stop offset=".55" style="stop-color:var(--hsa-gold,#B8924A);stop-opacity:var(--tr-rim-mid,0)"/><stop offset="1" style="stop-color:var(--hsa-gold,#B8924A);stop-opacity:0"/></linearGradient>`;
}
const line = (w, extra = '') => `${strokev('tr-line', '#B9A684', extra)} stroke-width="${W(w)}"`;
const rimH = (id, w = 0.6) => `stroke="url(#tr-${id}-rim)" fill="none" stroke-width="${W(w)}"`;
const rim = (w = 0.6) => `style="stroke:var(--hsa-gold,#B8924A);stroke-opacity:var(--tr-rim-op,0)" fill="none" stroke-width="${W(w)}" stroke-linecap="round"`;
const shade = (op) => fillv('tr-shadow', '#5A3A1E', `;fill-opacity:${op}`);

function medallion(cx) {         // static: revealed / covered only by the (opaque) coin
  const disc = `<circle cx="${cx}" cy="${MED_LY}" r="${MED_R}" ${fillv('tr-med', '#FBF6EA')} ${strokev('hsa-gold', '#B8924A', ';stroke-opacity:var(--tr-med-ring,1)')} stroke-width="${W(0.7)}"/>`;
  return disc + qGlyph(cx - 0.25, MED_LY - 0.3, 0.46, fillv('tr-med-ink', '#8E6B3A'));
}

// one closed outer outline per bank (stylobate + steps + cella + entablature + roof/drum/dome)
function silhouette(cx, kind) {
  const L = (x) => f1(cx - x), R = (x) => f1(cx + x);
  const left = `M${L(40)} 136V130H${L(37)}V126.4H${L(34)}V123H${L(30)}V85.6H${L(33)}V80.6H${L(34.5)}V77.8H${L(37)}V75.2`;
  const right = `V77.8H${R(34.5)}V80.6H${R(33)}V85.6H${R(30)}V123H${R(34)}V126.4H${R(37)}V130H${R(40)}V136z`;
  const top = kind === 'pediment'
    ? `L${cx} 58.4L${R(37)} 75.2`
    : `H${L(21)}V73.4H${L(17.5)}V61.5H${L(18.4)}V59.5H${L(17)}V59.7A17 15.5 0 0 1 ${R(17)} 59.7V59.5H${R(18.4)}V61.5H${R(17.5)}V73.4H${R(21)}V75.2H${R(37)}`;
  return `<path d="${left}${top}${right}" fill="none" ${strokev('tr-silhouette', '#B09A70', ';stroke-opacity:var(--tr-sil-a,1)')} stroke-width="${W(0.9)}" stroke-linejoin="round"/>`;
}

function bank(cx, kind, id) {
  const st = `url(#tr-${id}-stone)`;
  let s = '', rims = '', over = '';
  // ambient + contact shadow (down-right)
  s += `<ellipse cx="${cx + 6}" cy="136.4" rx="50" ry="5.2" fill="url(#tr-amb)"/>`;
  s += `<ellipse cx="${cx + 1.6}" cy="136.1" rx="42" ry="1.5" fill="url(#tr-contact)"/>`;
  // steps (upper tier casts a thin shadow onto the one below); line only on the step tops
  const tiers = [[40, 130, 6], [37, 126.4, 3.6], [34, 123, 3.4]];
  tiers.forEach(([hw, y, h], i) => {
    s += `<rect x="${cx - hw}" y="${y}" width="${hw * 2}" height="${h}" fill="${st}"/>`;
    if (i > 0) s += `<rect x="${cx - hw + 1.4}" y="${y + h}" width="${hw * 2}" height="1" ${shade(0.1)}/>`;
    s += `<path d="M${cx - hw} ${y}h${hw * 2}" fill="none" ${line(0.6)}/>`;
    rims += `<path d="M${cx - hw + .3} ${y + .3}h${hw * 2 - .6}" ${rimH(id)}/>`;
  });
  // cella wall (in the colonnade's shade) + entablature shadow on it
  s += `<rect x="${cx - 30}" y="85.6" width="60" height="37.4" fill="url(#tr-wall)"/>`;
  s += `<rect x="${cx - 30}" y="85.6" width="60" height="4" fill="url(#tr-castv)"/>`;
  // windows (plain arched recesses, the only outlined openings) and door (darkest recess, static)
  for (const dx of [-17, 17]) s += `<path d="M${cx + dx - 3.2} 110V98.2a3.2 3.2 0 0 1 6.4 0V110z" fill="url(#tr-win)" ${line(0.6)}/>`;
  const dw = 10.4, dh = 19, dTop = 123 - dh + dw / 2;
  s += `<path d="M${cx - dw / 2} 123V${dTop}a${dw / 2} ${dw / 2} 0 0 1 ${dw} 0V123z" fill="url(#tr-door)"/>`;
  rims += `<path d="M${cx - dw / 2} 123V${dTop}a${dw / 2} ${dw / 2} 0 0 1 ${dw / 2} ${-dw / 2}" style="stroke:var(--hsa-gold,#B8924A);stroke-opacity:var(--tr-door-rim,0)" fill="none" stroke-width="${W(0.6)}"/>`;
  rims += `<path d="M${cx} ${dTop - dw / 2}a${dw / 2} ${dw / 2} 0 0 1 ${dw / 2} ${dw / 2}" style="stroke:var(--hsa-gold,#B8924A);stroke-opacity:var(--tr-door-rim-r,0)" fill="none" stroke-width="${W(0.6)}"/>`;
  // columns: cast shadow on the wall (down-right), cylinder-gradient shaft, capital, base (no outlines)
  for (const dx of [-25, -9, 9, 25]) {
    const x = cx + dx;
    s += `<rect x="${x + 3.2}" y="88" width="${Math.min(2.8, cx + 30 - x - 3.2)}" height="32.2" ${shade(0.09)}/>`;
  }
  for (const dx of [-25, -9, 9, 25]) {
    const x = cx + dx;
    s += `<rect x="${x - 3.2}" y="87.6" width="6.4" height="32.6" fill="url(#tr-col)"/>`;
    s += `<rect x="${x + 2.2}" y="87.6" width="1" height="32.6" ${shade(0.06)}/>`;          // shaft terminator
    rims += `<path d="M${f1(x - 3.05)} 88.6V119.4" ${rim(0.6)}/>`;
    s += `<rect x="${x - 4.4}" y="85.6" width="8.8" height="2" fill="${st}"/>`;
    s += `<rect x="${x - 3.2}" y="87.6" width="6.4" height=".7" ${shade(0.12)}/>`;          // capital onto shaft
    s += `<rect x="${x - 4.2}" y="120.2" width="8.4" height="2.8" fill="${st}"/>`;
    s += `<rect x="${x - 4.2}" y="120.2" width="8.4" height=".6" fill="url(#tr-a-rimv)" style="fill-opacity:var(--tr-rim-op,0)"/>`;
  }
  // entablature: architrave, dentil frieze (9), cornice; each overhang shades the band below it
  s += `<rect x="${cx - 33}" y="80.6" width="66" height="5" fill="${st}"/>`;
  s += `<rect x="${cx - 30}" y="85.6" width="60" height=".8" ${shade(0.13)}/>`;              // architrave onto capitals / wall
  s += `<rect x="${cx - 34.5}" y="77.6" width="69" height="3" fill="${st}"/>`;
  s += `<rect x="${cx - 33}" y="80.6" width="66" height=".8" ${shade(0.1)}/>`;               // frieze onto architrave
  let dent = ''; for (let i = 0; i < 9; i++) dent += `M${f1(cx - 32 + i * 7.75)} 78.5h2.5v1.7h-2.5z`;
  s += `<path d="${dent}" ${fillv('tr-dentil', '#B9A684', ';fill-opacity:.6')}/>`;
  s += `<rect x="${cx - 34.5}" y="77.8" width="69" height=".9" ${shade(0.11)}/>`;            // cornice onto frieze
  s += `<rect x="${cx - 37}" y="75.2" width="74" height="2.6" fill="${st}"/>`;
  rims += `<path d="M${cx - 36.7} 75.5h73.4" ${rimH(id)}/>`;
  if (kind === 'pediment') {
    s += `<path d="M${cx - 37} 75.2L${cx} 58.4L${cx + 37} 75.2z" fill="${st}"/>`;
    s += `<path d="M${cx - 37} 75.2L${cx} 58.4L${cx + 37} 75.2" fill="none" ${strokev('tr-shadow', '#5A3A1E', ';stroke-opacity:.08')} stroke-width="${W(2.2)}" transform="translate(.5 .9)" clip-path="url(#tr-a-tymp)"/>`;
    over += `<path d="M${cx - 38.2} 75.6L${cx} 57.6L${cx + 38.2} 75.6" fill="none" ${strokev('tr-roof', '#9C7B47')} stroke-width="${W(1.1)}" stroke-linejoin="round" stroke-linecap="round"/>`;
    over += `<path d="M${cx - 37.4} 74.6L${cx - 0.6} 57.3" ${rim(0.6)}/>`;
    over += medallion(cx);
  } else {
    // plinth step, drum (attic) with the receiving medallion, drum cap, dome with thin gold ribs, lantern
    const DB = 59.7, RX = 17, RY = 15.5, DT = DB - RY, RW = 17.5;
    s += `<rect x="${cx - RW}" y="61.5" width="${RW * 2}" height="11.9" fill="url(#tr-col)"/>`;
    s += `<rect x="${cx - RW}" y="61.5" width="${RW * 2}" height="1.2" ${shade(0.12)}/>`;    // cap onto drum
    rims += `<path d="M${f1(cx - RW + .15)} 62.9V73" ${rim(0.6)}/>`;
    s += `<rect x="${cx - 21}" y="73.4" width="42" height="1.8" fill="${st}"/>`;
    s += `<path d="M${cx - 21} 73.4h42" fill="none" ${line(0.6)}/>`;
    s += `<rect x="${cx - 37}" y="75.2" width="74" height=".7" ${shade(0.1)}/>`;              // plinth onto cornice
    s += `<path d="M${cx - RX} ${DB}A${RX} ${RY} 0 0 1 ${cx + RX} ${DB}z" fill="url(#tr-dome)"/>`;
    let ribs = '';
    for (const k of [-0.62, -0.3, 0.3, 0.62]) ribs += `M${f1(cx + RX * k)} ${DB}A${f1(RX * Math.abs(k))} ${RY} 0 0 ${k < 0 ? 1 : 0} ${cx} ${f1(DT)}`;
    ribs += `M${cx} ${DB}V${f1(DT)}`;
    s += `<path d="${ribs}" fill="none" ${strokev('tr-rib', '#B8924A', ';stroke-opacity:var(--tr-rib-op,.55)')} stroke-width="${W(0.6)}"/>`;
    rims += `<path d="M${f1(cx - 16.9)} ${f1(DB - 1.4)}A${RX} ${RY} 0 0 1 ${f1(cx - 1.9)} ${f1(DT + 0.1)}" style="stroke:var(--tr-dome-rim,#B8924A);stroke-opacity:var(--tr-dome-rim-a,0)" fill="none" stroke-width="${W(0.7)}" stroke-linecap="round"/>`;
    s += `<rect x="${f1(cx - 18.4)}" y="59.5" width="36.8" height="2" fill="${st}"/>`;
    over += `<rect x="${cx - 2.8}" y="${f1(DT - 3.4)}" width="5.6" height="3.6" fill="${st}"/>`;
    over += `<path d="M${cx - 2.8} ${f1(DT - 3.4)}v3.6M${cx + 2.8} ${f1(DT - 3.4)}v3.6" fill="none" ${strokev('tr-silhouette', '#B09A70', ';stroke-opacity:var(--tr-sil-a,1)')} stroke-width="${W(0.7)}"/>`;
    over += `<path d="M${cx - 3.4} ${f1(DT - 3.2)}A3.4 2.6 0 0 1 ${cx + 3.4} ${f1(DT - 3.2)}z" ${fillv('hsa-gold', '#B8924A')}/>`;
    over += `<circle cx="${cx}" cy="${f1(DT - 6.6)}" r="1.1" ${fillv('hsa-gold', '#B8924A')}/>`;
    over += medallion(cx);
  }
  return s + silhouette(cx, kind) + rims + over;
}

function coin(r = COIN_R) {
  // The inner ring and the Q are sized so that at scale SINK they register exactly on the medallion
  // (medallion ring radius MED_R·K, Q scale .46·K, offset (-.25, -.3)·K, all in world units).
  const ringR = MED_R * K / SINK, qs = 0.46 * K / SINK, qx = -0.25 * K / SINK, qy = -0.3 * K / SINK;
  let s = '';
  s += `<circle r="12.8" fill="url(#tr-coinhalo)"/>`;
  s += `<g class="tr-coin-sh" opacity=".3"><circle cx="1.6" cy="2.2" r="9.2" fill="url(#tr-coinamb)"/></g>`;
  s += `<circle class="tr-coin-cs" cx=".5" cy=".7" r="${r + 0.1}" ${shade(0.2)} opacity="0"/>`;
  s += `<circle r="${r}" fill="url(#tr-coinbody)" ${strokev('tr-coin-lo', '#A8843F')} stroke-width=".75"/>`;
  s += `<circle r="${f1(ringR)}" fill="none" ${strokev('tr-coin-lo', '#A8843F', ';stroke-opacity:.6')} stroke-width=".6"/>`;
  s += qGlyph(+qx.toFixed(3), +qy.toFixed(3), +qs.toFixed(3), fillv('tr-coin-ink', '#6B4E23'));
  s += `<path d="M${f1(-r * 0.66)} ${f1(-r * 0.38)}A${r * 0.8} ${r * 0.8} 0 0 1 ${f1(r * 0.05)} ${f1(-r * 0.8)}" fill="none" ${strokev('tr-spec-c', '#FFFFFF', ';stroke-opacity:var(--tr-spec,.7)')} stroke-width=".7" stroke-linecap="round"/>`;
  return s;
}

const dashArr = (L) => `0 ${f1((C_OFF - L) * LEN)} ${f1(L * LEN)} ${f1(3 * LEN)}`;
const dashOff = (p) => +((C_OFF - p) * LEN + S0).toFixed(2);   // head at arc fraction p on the sub-path

function build() {
  const r0 = at(ROUTE[0]), r1 = at(ROUTE[1]);
  const off = dashOff(P_STATIC);
  const L0 = TRAIL[0].L;
  const defs = `<defs>
<radialGradient id="tr-halo" cx=".5" cy=".5" r=".5"><stop offset="0" style="stop-color:var(--hsa-halo,#FFFFFF);stop-opacity:var(--hsa-halo-a,.85)"/><stop offset=".6" style="stop-color:var(--hsa-halo,#FFFFFF);stop-opacity:var(--hsa-halo-b,.35)"/><stop offset="1" style="stop-color:var(--hsa-halo,#FFFFFF);stop-opacity:0"/></radialGradient>
<radialGradient id="tr-amb" cx=".5" cy=".5" r=".5">${stop(0, 'tr-shadow', '#5A3A1E', 0.13)}${stop(.6, 'tr-shadow', '#5A3A1E', 0.05)}${stop(1, 'tr-shadow', '#5A3A1E', 0)}</radialGradient>
<radialGradient id="tr-contact" cx=".5" cy=".5" r=".5">${stop(0, 'tr-shadow', '#5A3A1E', 0.26)}${stop(.7, 'tr-shadow', '#5A3A1E', 0.12)}${stop(1, 'tr-shadow', '#5A3A1E', 0)}</radialGradient>
<linearGradient id="tr-castv" x1="0" y1="0" x2="0" y2="1">${stop(0, 'tr-shadow', '#5A3A1E', 0.16)}${stop(1, 'tr-shadow', '#5A3A1E', 0)}</linearGradient>
<linearGradient id="tr-a-rimv" x1="0" y1="0" x2="1" y2="0"><stop offset="0" style="stop-color:var(--hsa-gold,#B8924A)"/><stop offset="1" style="stop-color:var(--hsa-gold,#B8924A);stop-opacity:0"/></linearGradient>
<clipPath id="tr-a-tymp"><path d="M27 75.2L64 58.4L101 75.2z"/></clipPath>
${stoneGrad('tr-a-stone', 64)}${stoneGrad('tr-b-stone', 256)}${rimGrad('tr-a-rim', 64)}${rimGrad('tr-b-rim', 256)}
<linearGradient id="tr-wall" x1="0" y1="0" x2="1" y2="0">${stop(0, 'tr-wall-hi', '#E6DCC8')}${stop(0.5, 'tr-wall', '#DDD1BB')}${stop(1, 'tr-wall-lo', '#CDBFA5')}</linearGradient>
<linearGradient id="tr-col" x1="0" y1="0" x2="1" y2="0">${stop(0, 'tr-stone', '#EFE7D8')}${stop(0.32, 'tr-stone-hi', '#FFFDF8')}${stop(1, 'tr-stone-lo', '#D9CCB4')}</linearGradient>
<linearGradient id="tr-win" x1="0" y1="0" x2="0" y2="1">${stop(0, 'tr-win-lo', '#CDBFA5')}${stop(0.45, 'tr-win', '#DED3BE')}${stop(1, 'tr-win-hi', '#E9E0CF')}</linearGradient>
<linearGradient id="tr-door" x1="0" y1="0" x2="1" y2="1">${stop(0, 'tr-door-hi', '#C9B48F')}${stop(0.5, 'tr-door', '#B49C74')}${stop(1, 'tr-door-lo', '#9E845B')}</linearGradient>
<radialGradient id="tr-dome" cx=".34" cy=".3" r=".85">${stop(0, 'tr-dome-hi', '#FFFDF8')}${stop(0.5, 'tr-dome', '#F2EADB')}${stop(1, 'tr-dome-lo', '#D6C8AE')}</radialGradient>
<radialGradient id="tr-coinbody" cx=".36" cy=".3" r=".75">${stop(0, 'tr-coin-hi', '#F6E4B0')}${stop(0.6, 'tr-coin', '#D6AE5E')}${stop(1, 'tr-coin-lo', '#A8843F')}</radialGradient>
<radialGradient id="tr-coinhalo" cx=".5" cy=".5" r=".5"><stop offset="0" style="stop-color:var(--tr-glow,#E2C27E);stop-opacity:var(--tr-halo-a,.34)"/><stop offset=".55" style="stop-color:var(--tr-glow,#E2C27E);stop-opacity:var(--tr-halo-b,.14)"/><stop offset="1" style="stop-color:var(--tr-glow,#E2C27E);stop-opacity:0"/></radialGradient>
<radialGradient id="tr-coinamb" cx=".5" cy=".5" r=".5">${stop(0, 'tr-shadow', '#5A3A1E', 0.14)}${stop(1, 'tr-shadow', '#5A3A1E', 0)}</radialGradient>
<linearGradient id="tr-ground" gradientUnits="userSpaceOnUse" x1="24" y1="0" x2="296" y2="0"><stop offset="0" style="stop-color:var(--tr-ground,#6B4E23);stop-opacity:0"/><stop offset=".5" style="stop-color:var(--tr-ground,#6B4E23);stop-opacity:var(--tr-ground-a,.18)"/><stop offset="1" style="stop-color:var(--tr-ground,#6B4E23);stop-opacity:0"/></linearGradient>
<linearGradient id="tr-routeg" gradientUnits="userSpaceOnUse" x1="${f1(r0[0])}" y1="0" x2="${f1(r1[0])}" y2="0"><stop offset="0" style="stop-color:var(--tr-route,#A88654);stop-opacity:0"/><stop offset=".07" style="stop-color:var(--tr-route,#A88654);stop-opacity:var(--tr-route-a,.8)"/><stop offset=".93" style="stop-color:var(--tr-route,#A88654);stop-opacity:var(--tr-route-a,.8)"/><stop offset="1" style="stop-color:var(--tr-route,#A88654);stop-opacity:0"/></linearGradient>
<mask id="tr-route-mask" maskUnits="userSpaceOnUse" x="0" y="0" width="320" height="180"><rect width="320" height="180" fill="#fff"/><path class="tr-mask-path" d="${trailD}" fill="none" stroke="#000" stroke-width="2.4" stroke-linecap="round" stroke-dasharray="${dashArr(L0)}" stroke-dashoffset="${off}"/></mask>
</defs>`;
  const pS = at(P_STATIC);
  const trail = TRAIL.map((l, i) => `<path class="tr-trail tr-trail--${i + 1}" d="${trailD}" fill="none" ${strokev('tr-trail', '#C9A35A', `;stroke-opacity:${TRAIL_OP}`)} stroke-width="${l.w}" stroke-linecap="round" stroke-dasharray="${dashArr(l.L)}" stroke-dashoffset="${off}"/>`).join('\n');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180" class="hsa-scene hsa-tr" aria-hidden="true" focusable="false">
${defs}
<g class="tr-backdrop">
<ellipse cx="160" cy="92" rx="150" ry="80" fill="url(#tr-halo)"/>
<path d="M24 ${GY + .5}H296" fill="none" stroke="url(#tr-ground)" stroke-width=".6"/>
</g>
<g class="tr-bank tr-bank--origen"><g transform="translate(${f1(TA[0])} ${f1(TA[1])}) scale(${K})">${bank(64, 'pediment', 'a')}</g></g>
<g class="tr-bank tr-bank--destino"><g transform="translate(${f1(TB[0])} ${f1(TB[1])}) scale(${K})">${bank(256, 'dome', 'b')}</g></g>
<path class="tr-route" d="${subRoute(ROUTE[0], ROUTE[1])}" fill="none" stroke="url(#tr-routeg)" stroke-width="1.1" stroke-dasharray="0 3.6" stroke-linecap="round" mask="url(#tr-route-mask)"/>
${trail}
<g class="tr-coin" transform="translate(${f1(pS[0])} ${f1(pS[1])})">${coin()}</g>
</svg>`;
}

// ---- keyframes generator (CSS) ----------------------------------------------------------------
function css() {
  const pc = (t) => +(t / T * 100).toFixed(2) + '%';
  const r2 = (n) => { const v = Math.round(n * 100) / 100; return Object.is(v, -0) ? 0 : v; };
  const tf = (x, y, rot, sc, op) => `transform: translate(${r2(x)}px, ${r2(y)}px) rotate(${r2(rot)}deg) scale(${r2(sc)}); opacity: ${op};`;
  // rows: [[t, ...], body]; a percentage claimed by a later row is removed from earlier rows (TR2-09)
  const emit = (rows) => {
    const later = new Set(); const out = [];
    for (let i = rows.length - 1; i >= 0; i--) {
      const keys = [...new Set(rows[i][0].map((t) => (t === 0 ? '0%' : t === T ? '100%' : pc(t))))].filter((k) => !later.has(k));
      keys.forEach((k) => later.add(k)); if (keys.length) out.unshift(`  ${keys.join(', ')} { ${rows[i][1]} }`);
    }
    return out.join('\n');
  };
  const kf = (name, rows) => `\n}\n@keyframes ${name} {\n${emit(rows)}`;
  const ease = 'cubic-bezier(.4, 0, .6, 1)';
  const LIN = ' animation-timing-function: linear;';
  // sample times: press, flight, settle
  const times = [];
  for (let t = TA0 + 30; t < TL; t += 30) times.push(t);
  for (let t = TL; t < TF - 1; t += (TF - TL) / 50) times.push(Math.round(t * 10) / 10);
  for (let t = TF; t < TS - 1; t += 28) times.push(t);
  const coinK = [[[0, TA0], tf(S[0], S[1], 0, 1, 1) + LIN]];
  for (const t of times) { const p = flightPos(t); coinK.push([[t], tf(p[0], p[1], lean(t), 1, 1) + LIN]); }
  // sink: scale eases OUT (the ring and Q reach register early) while opacity eases IN
  // (cubic-bezier(.55,0,1,.45)-like), so translucent frames are few and already in register.
  // The emergence at the origin is the exact time mirror. Sampled, linear between samples.
  const bez = (x1, y1, x2, y2) => (x) => { let lo = 0, hi = 1; for (let k = 0; k < 40; k++) { const m = (lo + hi) / 2, bx = 3 * (1 - m) ** 2 * m * x1 + 3 * (1 - m) * m * m * x2 + m ** 3; if (bx < x) lo = m; else hi = m; } const m = (lo + hi) / 2; return 3 * (1 - m) ** 2 * m * y1 + 3 * (1 - m) * m * m * y2 + m ** 3; };
  const opIn = bez(.55, 0, 1, .45), scOut = (u) => 1 - (1 - u) ** 2.4;
  const sinkAt = (u) => [1 - (1 - SINK) * scOut(u), +(1 - opIn(u)).toFixed(3)];
  coinK.push([[TS, TD0], tf(E[0], E[1], 0, 1, 1) + LIN]);
  const NS = 8;
  for (let k = 1; k < NS; k++) { const [sc, op] = sinkAt(k / NS); coinK.push([[TD0 + (TD1 - TD0) * k / NS], `transform: translate(${E[0]}px, ${r2(E[1])}px) rotate(0deg) scale(${sc.toFixed(3)}); opacity: ${op};` + LIN]); }
  coinK.push([[TD1], tf(E[0], E[1], 0, SINK, 0) + ' animation-timing-function: step-end;']);
  coinK.push([[TE0], tf(S[0], S[1], 0, SINK, 0) + LIN]);
  for (let k = 1; k < NS; k++) { const [sc, op] = sinkAt(1 - k / NS); coinK.push([[TE0 + (TE1 - TE0) * k / NS], `transform: translate(${S[0]}px, ${r2(S[1])}px) rotate(0deg) scale(${sc.toFixed(3)}); opacity: ${op};` + LIN]); }
  coinK.push([[TE1, T], tf(S[0], S[1], 0, 1, 1)]);
  // comet + mask: every dash covers [p - L, p]; shared offset (dash arrays differ per layer)
  const litR = [[[0, TL], `stroke-dashoffset: ${dashOff(0)}px;` + LIN]];
  for (const t of times) { if (t <= TL) continue; litR.push([[t], `stroke-dashoffset: ${dashOff(Math.max(0, progress(t)))}px;` + LIN]); }
  litR.push([[TF, TD1], `stroke-dashoffset: ${dashOff(Math.max(0, progress(TF)))}px; animation-timing-function: step-end;`]);
  litR.push([[TD1 + 50, T], `stroke-dashoffset: ${dashOff(0)}px;`]);
  let out = emit(litR);
  // per-layer opacity: nothing before the coin has cleared the pediment roof
  const span = TF - TL;
  const tClear = firstT((t) => progress(t) >= TRAIL_U0 + 0.02, TL, TF);
  TRAIL.forEach((l, i) => {
    const tin = Math.max(TL + span * l.in, tClear + 80), a = TL + span * l.f[0], b = TL + span * l.f[1];
    out += kf(`tr-trail-${i + 1}`, [
      [[0, tClear], `opacity: 0; animation-timing-function: cubic-bezier(.3, 0, .6, 1);`],
      [[tin, Math.max(a, tin)], `opacity: 1; animation-timing-function: ${ease};`],
      [[b, T], `opacity: 0;`]]);
  });
  // coin shadows: ambient thins out in flight and comes back while the coin descends onto the
  // drum (depth cue, QA-04); contact shadow only while seated on a medallion
  out += kf('tr-coin-sh', [
    [[0, TL], `opacity: 1; animation-timing-function: ${ease};`],
    [[TL + 200, TF - 560], `opacity: .3; animation-timing-function: ${ease};`],
    [[TF - 330, T], `opacity: 1;`]]);
  out += kf('tr-coin-cs', [
    [[0, TL], `opacity: 1; animation-timing-function: ${ease};`],
    [[TL + 160, TF - 160], `opacity: 0; animation-timing-function: ${ease};`],
    [[TF + 80, T], `opacity: 1;`]]);
  return { coin: emit(coinK), lit: out };
}
module.exports = { build, css, _dbg: { S, E, AP, SEGS, LEN, D0, D1, at, progress, flightPos, lean, clearDest, aboveRoof, T, TA0, TL, TF, TS, TD0, TD1, TE0, TE1, ROUTE, TRAIL_U0, S0, TRAIL, K, GY, MY, COIN_R, SINK } };
if (require.main === module) {
  const k = css();
  console.log('@keyframes tr-coin {\n' + k.coin + '\n}\n@keyframes tr-lit {\n' + k.lit + '\n}');
}
